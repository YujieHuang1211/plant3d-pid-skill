﻿# 出图批处理（Windows PowerShell 5）
#   build_set.ps1 -Project <Project.xml> -Specs <specs目录> -Pdf <PDF目录> -Backup <zip目录> -Sheets "P&ID-101|P&ID-101_xxx.dwg;..."
#     [-Session single|per-sheet]  single（默认）：一个 AutoCAD 会话画完全部图纸，文档不关闭；per-sheet：每张图重启（旧方式，备用）
#     [-Redraw]                    只重画 -Sheets 中的图：移除旧图并清理空线组 → 重画 → 重新配对跨图连接器
#     [-RedrawSession two|one]     two（默认）：移除+清理与重画分两个会话。one 在基准项目 2 次通过，但正式项目一次重画 4 张时（清理 48 个线组后画到第 3 张）eNotOpenForWrite 闪退，故不作默认
#     [-Plain]                     普通图元模式：spec 只含 sym/poly/text/table（plain_convert.py 生成），库里没有 Plant 对象，跳过 verify_topology / check_orphans
#     [-Reopen]                    结束后在全新会话中重开各图核对位号
# 规则：
#   - 先做 spec 静态检查（lint），不通过不启动 AutoCAD
#   - 出图前与每张通过后各打一个 zip（排除 *.dwl/*.dwl2 锁文件），作为可恢复版本
#   - Plant 状态异常/对话框/超时：失败现场改名留证，用最近 zip 恢复，新会话从该图继续（只重试一次）；spec 错误立即停止
#   - 不直接修改项目数据库
param([string]$Project, [string]$Specs, [string]$Pdf, [string]$Backup, [string]$Sheets,
      [ValidateSet('single', 'per-sheet')][string]$Session = 'single', [switch]$Redraw, [switch]$Plain, [ValidateSet('one', 'two')][string]$RedrawSession = 'two', [switch]$Reopen,
      [string]$Tools = 'C:\Users\yujie\.claude\skills\plant3d-pid\scripts',
      [string]$StyleCfg = 'E:\05p_id图绘制中心\_PidBot\specs\qmz_stylecfg.json')
$ErrorActionPreference = 'Stop'
# 普通图元模式没有 Plant 对象，重画不会触发 eNotOpenForWrite，默认同一会话接着画（省一次约 140 s 的启动）
if ($Plain -and -not $PSBoundParameters.ContainsKey('RedrawSession')) { $RedrawSession = 'one' }
Import-Module (Join-Path $PSScriptRoot 'pidbot.psm1') -DisableNameChecking
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
$log = 'E:\05p_id图绘制中心\_PidBot\logs'
$cfg = $StyleCfg
$prjDir = Split-Path $Project
$prjName = Split-Path $prjDir -Leaf
$dcf = Join-Path $prjDir 'ProcessPower.dcf'
New-Item -ItemType Directory -Force $Pdf, $Backup | Out-Null
$env:PYTHONIOENCODING = 'utf-8'
$sw = [Diagnostics.Stopwatch]::StartNew()
function T { '{0,5:N0}s' -f $sw.Elapsed.TotalSeconds }
$list = @($Sheets -split ';' | Where-Object { $_.Trim() } | ForEach-Object { $a = $_.Split('|'); [pscustomobject]@{ No = $a[0].Trim(); Dwg = $a[1].Trim() } })

# ---------------------------------------------------------------- 备份/恢复（AutoCAD 运行中也可打包：只读共享打开，跳过锁文件）
function Save-Zip([string]$zip) {
  if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip }
  $za = [IO.Compression.ZipFile]::Open($zip, 'Create')
  try {
    $add = {
      param($file, $name)
      $e = $za.CreateEntry($name, [IO.Compression.CompressionLevel]::Fastest)
      $src = [IO.File]::Open($file, 'Open', 'Read', 'ReadWrite, Delete')
      try { $dst = $e.Open(); try { $src.CopyTo($dst) } finally { $dst.Dispose() } } finally { $src.Dispose() }
    }
    foreach ($f in Get-ChildItem -LiteralPath $prjDir -Recurse -File) {
      if ($f.Extension -match '^\.dwl2?$') { continue }
      & $add $f.FullName ($f.FullName.Substring($prjDir.Length + 1).Replace('\', '/'))
    }
    foreach ($f in Get-ChildItem -LiteralPath $Specs -Filter '*.ids.json' -File) { & $add $f.FullName ('_ids/' + $f.Name) }
  } finally { $za.Dispose() }
}
function Restore-Zip([string]$zip, [string[]]$dropIds) {
  $evid = '{0}_失败_{1}' -f $prjDir, (Get-Date -Format 'MMdd_HHmmss')
  Rename-Item -LiteralPath $prjDir -NewName (Split-Path $evid -Leaf)
  [IO.Compression.ZipFile]::ExtractToDirectory($zip, $prjDir)
  $idsDir = Join-Path $prjDir '_ids'
  if (Test-Path -LiteralPath $idsDir) {
    Get-ChildItem -LiteralPath $Specs -Filter '*.ids.json' -File | Remove-Item
    Get-ChildItem -LiteralPath $idsDir -File | Move-Item -Destination $Specs -Force
    Remove-Item -LiteralPath $idsDir -Recurse
  }
  foreach ($n in $dropIds) { foreach ($x in "$Specs\$n.ids.json", "$Specs\$n.anno.lsp") { if (Test-Path -LiteralPath $x) { Remove-Item -LiteralPath $x } } }
  "已用 $(Split-Path $zip -Leaf) 恢复；失败现场保留为 $(Split-Path $evid -Leaf)"
}
function Last-Zip { (Get-ChildItem -LiteralPath $Backup -Filter "${prjName}_*.zip" | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName }

# ---------------------------------------------------------------- 单张图（在当前会话中）；返回 ok / spec / transient
function Step([string]$verb, [string]$arg, [int]$t = 300) {
  # AutoCAD 中途退出/无响应时 Invoke-PbVerb 会抛异常：按偶发故障处理（恢复后重试），不让整批中断
  try { $r = Invoke-PbVerb $verb $arg $t } catch { "  [$verb] 异常: $($_.Exception.Message)"; return 'transient' }
  if (-not ((Get-Process acad -ErrorAction SilentlyContinue | Where-Object { $_.Threads.Count -gt 0 }))) { "  [$verb] AutoCAD 已退出"; return 'transient' }
  $d = @(Get-AcadDialogs)
  $r | Select-String '错误|失败 [a-z]|超时|完成：|已存盘|已输出' | ForEach-Object { "  [$verb] " + $_.Line }
  if ($d.Count) { "  !! 对话框: $($d -join ' / ')"; return 'transient' }
  if ($r -match '超时') { return 'transient' }
  if ($r -match 'Plant 对象状态异常') { return 'transient' }
  if ($r -match '错误:' -or $r -match '失败 [a-z]') { return 'spec' }
  'ok'
}
function Draw-Sheet($s) {
  $f = Join-Path (Join-Path $prjDir 'PID DWG') $s.Dwg
  $steps = @()
  if (Test-Path -LiteralPath $f) { $steps += , @('rmdwg', $s.Dwg, 60) }
  $steps += , @('newdwg', $s.Dwg, 120)
  $steps += , @('dwgprops', "$Specs\$($s.No).props.json", 60)
  $steps += , @('syncstyles', $cfg, 300)
  $steps += , @('draw', "$Specs\$($s.No).json", 600)
  foreach ($st in $steps) {
    $res = @(Step $st[0] $st[1] $st[2])
    $res | Where-Object { $_ -notin 'ok', 'spec', 'transient' }
    $code = $res[-1]
    if ($code -ne 'ok') {
      # 崩溃时 <动词>.log 尚未写出，现场只在 <动词>.live.log 里：带时间戳留证到备份目录的 _故障留证（不会被重试覆盖）
      $inc = Join-Path $Backup '_故障留证'; New-Item -ItemType Directory -Force $inc | Out-Null
      $stamp = Get-Date -Format 'MMdd_HHmmss'
      foreach ($v in @($st[0], 'draw', 'newdwg') | Select-Object -Unique) {
        Copy-Item "$log\$v.live.log" (Join-Path $inc ("{0}_{1}_{2}.live.log" -f $s.No, $v, $stamp)) -Force -ErrorAction SilentlyContinue
      }
      return $code
    }
  }
  Copy-Item "$log\draw.log" "$log\draw_$($s.No).log" -Force
  $anno = "$Specs\$($s.No).anno.lsp"
  if (Test-Path -LiteralPath $anno) { try { "  [anno] " + (Invoke-PbAnno $anno) } catch { "  [anno] 异常: $($_.Exception.Message)"; return 'transient' } }
  foreach ($st in @(@('regen', 'x', 120), @('qsave', 'x', 60))) { $res = @(Step $st[0] $st[1] $st[2]); $res | Where-Object { $_ -notin 'ok', 'spec', 'transient' }; if ($res[-1] -ne 'ok') { return $res[-1] } }
  Start-Sleep 2
  for ($try = 1; $try -le 4; $try++) {
    $res = @(Step 'pdf' "$Pdf\$($s.No).pdf" 180)
    $res | Where-Object { $_ -notin 'ok', 'spec', 'transient' }
    # 后台打印尚未结束（eBackgroundPlotInProgress）不是 spec 错误：等一会儿重试
    if ($res[-1] -eq 'ok' -or -not ($res -match 'eBackgroundPlotInProgress')) { break }
    "  [pdf] 后台打印未结束，15 s 后重试（$try/4）"; Start-Sleep 15
  }
  return $res[-1]
}

# 重画准备：移除旧图（若在项目中）、删除其 id 登记与标注脚本，清理空线组
function Prep-Redraw($sheets) {
  foreach ($s in $sheets) {
    if (Test-Path -LiteralPath (Join-Path (Join-Path $prjDir 'PID DWG') $s.Dwg)) { (Invoke-PbVerb rmdwg $s.Dwg 60) | Select-String '移除|错误' | ForEach-Object { "  $($_.Line)" } }
    foreach ($x in "$Specs\$($s.No).ids.json", "$Specs\$($s.No).anno.lsp") { if (Test-Path -LiteralPath $x) { Remove-Item -LiteralPath $x } }
  }
  if (-not $Plain) { (Invoke-PbVerb purge x 120) | Select-String '空线组|错误' | ForEach-Object { "  $($_.Line)" } }
}

function Verify([string[]]$nos, [string]$tag) {
  $v = & python "$Tools\verify_topology.py" $dcf $Specs "$log\verify_$tag.json" @nos 2>&1 | ForEach-Object { "$_" }
  $v | Select-Object -Last 3 | ForEach-Object { Write-Host $_ }   # 只把布尔值作为返回值
  return [bool]($v -match '^PASS')
}

# ---------------------------------------------------------------- 开始
$lint = & python "$Tools\lint_specs.py" $Specs @($list.No) 2>&1 | ForEach-Object { "$_" }
$lint | Select-Object -Last 12
if (-not ($lint -match 'LINT PASS')) { throw 'spec 静态检查未通过，未启动 AutoCAD' }
$null = Stop-Acad
$base = Join-Path $Backup ("{0}_出图前.zip" -f $prjName)
if ($Redraw) { $base = Join-Path $Backup ("{0}_重画前_{1}.zip" -f $prjName, (Get-Date -Format 'MMdd_HHmm')) }
if (-not (Test-Path -LiteralPath $base)) { Save-Zip $base; "$(T) 已备份 $(Split-Path $base -Leaf)" }
$last = if ($Redraw) { $base } else { Last-Zip }

if ($Redraw) {
  # 移除旧图 + 清理空线组：独立会话，不与绘图混在同一会话（曾在绘图会话中清理导致闪退）
  "$(T) 重画准备：移除旧图并清理空线组"
  Start-Acad $Project | Select-String '就绪|当前项目|启动耗时' | ForEach-Object { "  $($_.Line)" }
  Prep-Redraw $list
  if ($RedrawSession -eq 'two') { $null = Stop-Acad } else { $started = $true }   # one：同一会话接着重画（省一次启动）
}

$done = @(Get-ChildItem -LiteralPath $Specs -Filter '*.ids.json' -File | ForEach-Object { $_.Name -replace '\.ids\.json$', '' } | Where-Object { $_ -notin $list.No -and -not $_.StartsWith('_') })
if (-not $Redraw -or $RedrawSession -eq 'two') { $started = $false }
foreach ($s in $list) {
  if ($Session -eq 'per-sheet' -and $started) { $null = Stop-Acad; $started = $false }
  if (-not $started) { "$(T) 启动 AutoCAD"; Start-Acad $Project | Select-String '就绪|当前项目|启动耗时' | ForEach-Object { "  $($_.Line)" }; $started = $true }
  "$(T) === $($s.No)"
  $res = @(Draw-Sheet $s); $res | Select-Object -SkipLast 1; $code = $res[-1]
  # 偶发故障（崩溃/卡死/超时）：留证 → 用最近 zip 恢复 → 新会话重试，最多 3 次（单次成功率约一半到三分之二，2026-10-16 实测）
  for ($retry = 1; $code -eq 'transient' -and $retry -le 3; $retry++) {
    "!! $($s.No) Plant 状态异常/对话框/超时：留证、恢复、新会话重试（$retry/3）"
    $null = Stop-Acad; $started = $false
    Restore-Zip $last @($s.No)
    Start-Acad $Project | Select-String '就绪|当前项目|启动耗时' | ForEach-Object { "  $($_.Line)" }; $started = $true
    # 重画模式：恢复的 zip 可能带回尚未重画的旧图，先重新移除并清理空线组
    if ($Redraw) { Prep-Redraw @($list | Where-Object { $_.No -notin $done }) }
    $res = @(Draw-Sheet $s); $res | Select-Object -SkipLast 1; $code = $res[-1]
  }
  if ($code -ne 'ok') { $null = Stop-Acad; throw "$($s.No) 绘图失败（$code），停止本批；日志 $log\draw_$($s.No)_失败.log" }
  $done += $s.No
  $zip = Join-Path $Backup ("{0}_{1}_通过后.zip" -f $prjName, $s.No)
  Save-Zip $zip; $last = $zip
  "$(T) $($s.No) 已画完并备份"
}

if ($Redraw -and -not $Plain) {
  $mini = Join-Path $Specs '_repair_opc.json'
  if (Test-Path -LiteralPath $mini) { Remove-Item -LiteralPath $mini }
  & python "$Tools\repair_opc.py" $Specs ($list.No -join ',') $mini
  if (Test-Path -LiteralPath $mini) {
    $r = @(Step draw $mini 120); $r | Where-Object { $_ -notin 'ok', 'spec', 'transient' }
    Remove-Item -LiteralPath $mini; foreach ($x in "$Specs\_repair_opc.ids.json", "$Specs\_repair_opc.anno.lsp") { if (Test-Path -LiteralPath $x) { Remove-Item -LiteralPath $x } }
    if ($r[-1] -ne 'ok') { $null = Stop-Acad; throw '跨图连接器重新配对失败' }
    $null = Invoke-PbVerb qsave x 60
  }
}
$null = Stop-Acad
"$(T) 会话结束，核查全部已出图纸"
$allIds = @(Get-ChildItem -LiteralPath $Specs -Filter '*.ids.json' -File | ForEach-Object { $_.Name -replace '\.ids\.json$', '' } | Where-Object { -not $_.StartsWith('_') })
$order = @($done | Where-Object { $_ -in $allIds }) + @($allIds | Where-Object { $_ -notin $done })
if ($Plain) { "普通图元模式：跳过 Plant 库核查（位号与线号核对用 check_plain.py（对照 spec），PDF 元数据用 clean_pdf_meta.py）" }
else {
  if (-not (Verify $order 'set')) { throw "库核查未通过（$log\verify_set.json）" }
  & python "$Tools\check_orphans.py" $dcf "$log\orphans_set.json" | ForEach-Object { Write-Host $_ }
  if ($LASTEXITCODE -ne 0) { throw "项目库有残留（$log\orphans_set.json）" }
}
if ($Redraw) { $zip = Join-Path $Backup ("{0}_重画后_{1}.zip" -f $prjName, (Get-Date -Format 'MMdd_HHmm')); Save-Zip $zip; "已备份 $(Split-Path $zip -Leaf)" }

if ($Reopen) {
  "$(T) 重开核对"
  Start-Acad $Project | Select-String '当前项目' | ForEach-Object { "  $($_.Line)" }
  foreach ($s in $list) {
    $r = Invoke-PbVerb opendwg $s.Dwg 120
    if ($r -match '错误|超时') { $r; $null = Stop-Acad; throw "打开失败 $($s.Dwg)" }
    $null = Invoke-PbVerb info x 120
    $out = "$log\reopen_$([IO.Path]::GetFileNameWithoutExtension($s.Dwg)).info.log"
    Copy-Item "$log\info.log" $out -Force
    & python "$Tools\reopen_check.py" $out $Specs $s.No "$log\reopen_$($s.No).json"
  }
  $null = Stop-Acad
}
"$(T) 全部完成: $($list.No -join ', ')"









