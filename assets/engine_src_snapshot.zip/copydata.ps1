﻿# 通过 WM_COPYDATA 向 AutoCAD 当前文档发送命令字符串（不依赖 COM）。用法: powershell -File copydata.ps1 -Text "PIDBOT_INFO`n"
param([string]$Text)
Add-Type -TypeDefinition @"
using System; using System.Runtime.InteropServices;
public class CD {
 [StructLayout(LayoutKind.Sequential)] public struct COPYDATASTRUCT { public IntPtr dwData; public int cbData; public IntPtr lpData; }
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, ref COPYDATASTRUCT cds);
 public static void Send(IntPtr h, string s){ var p=Marshal.StringToHGlobalUni(s); var c=new COPYDATASTRUCT{ dwData=(IntPtr)1, cbData=(s.Length+1)*2, lpData=p }; SendMessage(h,0x004A,IntPtr.Zero,ref c); Marshal.FreeHGlobal(p);} }
"@
$h=(Get-Process acad).MainWindowHandle
[CD]::Send($h, $Text.Replace('\n',"`n"))