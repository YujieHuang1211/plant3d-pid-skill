﻿# 重开核查（Windows PowerShell 5）：全新会话打开项目与图纸，导出对象清单到 logs\reopen_<图名>.info.log
#   reopen_check.ps1 -Project <Project.xml> -Dwgs "A.dwg","B.dwg"
param([string]$Project, [string]$Dwgs)   # 图名用英文逗号分隔
$ErrorActionPreference = 'Stop'
$s = 'E:\05p_id图绘制中心\_PidBot\scripts\send.ps1'
$c = 'E:\05p_id图绘制中心\_PidBot\scripts\acadctl.ps1'
& powershell -NoProfile -File $c -Quit
$rs = & powershell -NoProfile -File $c -Restart -Project $Project 2>&1
$rs | Select-String '当前项目|就绪|图形修复|启动'
if (-not ($rs -match '当前项目')) { throw '重启 AutoCAD 或打开项目失败，停止' }
foreach ($d in ($Dwgs -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })) {
  $r = & powershell -NoProfile -File $s -Verb opendwg -Arg $d -TimeoutSec 120
  if ($r -match '错误|超时') { $r; throw "打开失败 $d" }
  $r = & powershell -NoProfile -File $s -Verb info -Arg 'x' -TimeoutSec 120
  if ($r -match '超时') { throw "info 超时 $d" }
  $out = "E:\05p_id图绘制中心\_PidBot\logs\reopen_$([IO.Path]::GetFileNameWithoutExtension($d)).info.log"
  Copy-Item 'E:\05p_id图绘制中心\_PidBot\logs\info.log' $out -Force
  "已导出 $out"
}
