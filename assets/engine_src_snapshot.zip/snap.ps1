﻿# 截取 AutoCAD 进程的可见窗口（不截全屏）。用法: powershell -File snap.ps1 -OutDir <dir>
param([string]$OutDir)
Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @"
using System; using System.Runtime.InteropServices; using System.Text; using System.Collections.Generic; using System.Drawing;
public class W2 { public delegate bool EP(IntPtr h, IntPtr l);
[DllImport("user32.dll")] public static extern bool EnumWindows(EP f, IntPtr l);
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
[DllImport("user32.dll")] public static extern bool IsWindowEnabled(IntPtr h);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
[DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint f);
public struct RECT { public int L,T,R,B; }
public static List<IntPtr> List(uint p){ var r=new List<IntPtr>(); EnumWindows((h,l)=>{uint pid; GetWindowThreadProcessId(h,out pid); if(pid==p && IsWindowVisible(h)) r.Add(h); return true;}, IntPtr.Zero); return r; }
public static string Desc(IntPtr h){ var s=new StringBuilder(256); GetWindowText(h,s,256); var c=new StringBuilder(256); GetClassName(h,c,256); RECT rc; GetWindowRect(h,out rc); return h+" | "+c+" | "+s+" | "+rc.L+","+rc.T+","+rc.R+","+rc.B+" iconic="+IsIconic(h)+" enabled="+IsWindowEnabled(h); }
public static void Snap(IntPtr h, string f){ RECT rc; GetWindowRect(h,out rc); int w=rc.R-rc.L, hh=rc.B-rc.T; if(w<=0||hh<=0) return; using(var b=new Bitmap(w,hh)){ using(var g=Graphics.FromImage(b)){ var dc=g.GetHdc(); PrintWindow(h,dc,2); g.ReleaseHdc(dc);} b.Save(f);} } }
"@
$i=0; foreach($h in [W2]::List((Get-Process acad).Id)){ [W2]::Desc($h); [W2]::Snap($h, (Join-Path $OutDir "win$i.png")); $i++ }