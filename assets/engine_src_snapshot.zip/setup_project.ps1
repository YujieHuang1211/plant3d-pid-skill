﻿# 新建并配置一个 P&ID 项目（PIP 公制 + 项目符号库 + GB 图框模板），独立 AutoCAD 会话，完成后退出
#   setup_project.ps1 -Name "某某测试台" -Parent "E:/05p_id图绘制中心" [-Description "..."] [-ProjProps <projprops.json>] [-Paper A3|A1] [-TemplateName "某某_PID_A3_GB.dwt"]
#   projprops.json：{"Project_Description":"..","Project_Number":"待定","Client_Information_Company_Name":"..","Project_Data_DesignOrg":" "}
#   （设计单位不填时写一个空格：标题栏字段为空值时可能显示占位符）
param([string]$Name, [string]$Parent, [string]$Description = '', [string]$ProjProps = '',
      [ValidateSet('A3', 'A1')][string]$Paper = 'A3', [string]$TemplateName = '')
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'pidbot.psm1') -DisableNameChecking
$sp = 'E:\05p_id图绘制中心\_PidBot\specs'
if (-not $ProjProps) { $ProjProps = "$sp\qmz_projprops.json" }
if (-not $Description) { $Description = "$Name P&ID（PIP 公制符号 + 项目自定义符号 + GB $Paper 图框）" }
if (-not $TemplateName) { $TemplateName = "${Name}_PID_${Paper}_GB.dwt" }
$prjDir = Join-Path $Parent $Name
$prj = Join-Path $prjDir 'Project.xml'
if (Test-Path -LiteralPath $prj) { throw "项目已存在: $prj" }
New-Item -ItemType Directory -Force $Parent | Out-Null
$tmp = Join-Path $env:TEMP "pid_setup_$([guid]::NewGuid().ToString('N'))"; New-Item -ItemType Directory $tmp | Out-Null
@{ name = $Name; description = $Description; parentDir = $Parent } | ConvertTo-Json | Set-Content "$tmp\newproject.json" -Encoding UTF8
$dwt = Join-Path $prjDir "PID DWG\模板\$TemplateName"
@{ base = 'E:/AutoCAD Mechanical 2026/AutoCAD 2026/PLNT3D/UserDataCache/zh-CN/Template/PID ISO A1 -Color Dependent Plot Styles.dwt'; out = $dwt; paper = $Paper; layout = "$Paper GB 标题栏"; stylecfg = "$sp\qmz_stylecfg.json" } | ConvertTo-Json | Set-Content "$tmp\mkdwt.json" -Encoding UTF8
function Step($verb, $arg, $t = 300) {
  $r = Invoke-PbVerb $verb $arg $t
  $d = @(Get-AcadDialogs)
  if ($d.Count) { "!! 对话框: $($d -join ' / ')"; throw "AutoCAD 出现对话框，停止（日志保留在 _PidBot\logs）" }
  $r | Select-String '错误|失败|超时|完成|已|新增|当前项目|共 ' | ForEach-Object { "  [$verb] " + $_.Line }
  if ($r -match '错误:' -or $r -match '超时') { throw "$verb 报错或超时，停止（日志保留在 _PidBot\logs）" }
}
$null = Stop-Acad
Start-Acad | Select-String '就绪|NETLOAD|启动' | ForEach-Object { $_.Line }
Step 'newproject' "$tmp\newproject.json"
Step 'openproject' $prj 120
Step 'tagformats' "$sp\qmz_tagformats.json"
Step 'schema' "$sp\qmz_schema.json"
Step 'stylecfg' "$sp\qmz_stylecfg.json"
New-Item -ItemType Directory -Force (Split-Path $dwt) | Out-Null
Step 'mkdwt' "$tmp\mkdwt.json"
Step 'settemplate' $dwt 60
Step 'projprops' $ProjProps 60
$null = Stop-Acad
"项目配置完成: $prj"

