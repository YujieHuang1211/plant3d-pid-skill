﻿# PidBot 驱动模块（Windows PowerShell 5）：一个批处理进程内加载一次，避免每条命令都起子进程并重新编译 Add-Type。
#   Import-Module E:\05p_id图绘制中心\_PidBot\scripts\pidbot.psm1
#   Start-Acad -Project <Project.xml>   启动 Plant 3D、加载 PidBot、打开项目
#   Invoke-PbVerb draw <spec.json>      发送 PB/PBS 命令并返回 logs\<verb>.log 内容
#   Invoke-PbAnno <x.anno.lsp> / Get-AcadDialogs [-Click OK] / Stop-Acad / Set-RecoveryMode 2
# send.ps1、acadctl.ps1 保留原参数，内部调用本模块，旧脚本照常可用。
$script:Root = 'E:\05p_id图绘制中心\_PidBot'
$script:Exe = 'E:\AutoCAD Mechanical 2026\AutoCAD 2026\acad.exe'
$script:Tpl = 'E:\AutoCAD Mechanical 2026\AutoCAD 2026\PLNT3D\UserDataCache\zh-CN\Template\PID ISO A1 -Color Dependent Plot Styles.dwt'
$script:SessionVerbs = @('newproject', 'openproject', 'newdwg', 'styles', 'rmdwg', 'opendwg')
$script:Esc = [string][char]27 + [string][char]27

if (-not ('PbWin' -as [type])) {
  Add-Type -TypeDefinition @"
using System; using System.Runtime.InteropServices; using System.Text; using System.Collections.Generic;
public class PbWin {
 [StructLayout(LayoutKind.Sequential)] public struct COPYDATASTRUCT { public IntPtr dwData; public int cbData; public IntPtr lpData; }
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, ref COPYDATASTRUCT cds);
 [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, int m, IntPtr w, IntPtr l);
 public delegate bool EP(IntPtr h, IntPtr l);
 [DllImport("user32.dll")] public static extern bool EnumWindows(EP f, IntPtr l);
 [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr p, EP f, IntPtr l);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
 static string T(IntPtr h){ var s=new StringBuilder(512); GetWindowText(h,s,512); return s.ToString(); }
 static string C(IntPtr h){ var s=new StringBuilder(256); GetClassName(h,s,256); return s.ToString(); }
 public static void Send(IntPtr h, string s){ var p=Marshal.StringToHGlobalUni(s); var c=new COPYDATASTRUCT{ dwData=(IntPtr)1, cbData=(s.Length+1)*2, lpData=p }; SendMessage(h,0x004A,IntPtr.Zero,ref c); Marshal.FreeHGlobal(p);}
 // 主框架窗口（AfxMDIFrame*）；Process.MainWindowHandle 可能返回浮动选项板，命令会丢
 public static IntPtr Frame(uint pid){ IntPtr r=IntPtr.Zero; EnumWindows((h,l)=>{ uint p; GetWindowThreadProcessId(h,out p); if(p==pid && C(h).StartsWith("AfxMDIFrame")){ r=h; return false; } return true; }, IntPtr.Zero); return r; }
 public static List<IntPtr> Dlgs(uint pid){ var r=new List<IntPtr>(); EnumWindows((h,l)=>{ uint p; GetWindowThreadProcessId(h,out p); if(p==pid && IsWindowVisible(h) && C(h)=="#32770") r.Add(h); return true; }, IntPtr.Zero); return r; }
 public static string Describe(IntPtr d){ var sb=new StringBuilder(T(d)+" | "); EnumChildWindows(d,(h,l)=>{ var t=T(h); if(t.Length>0) sb.Append(C(h)+":"+t.Replace("\n"," ")+"; "); return true; }, IntPtr.Zero); return sb.ToString(); }
 public static bool ClickBtn(IntPtr d, string want){ bool ok=false; EnumChildWindows(d,(h,l)=>{ if(C(h)=="Button" && T(h).Replace("&","")==want){ SendMessage(h,0x00F5,IntPtr.Zero,IntPtr.Zero); ok=true; return false; } return true; }, IntPtr.Zero); return ok; }
}
"@
}

# 只管理本脚本自己启动的 AutoCAD：机器上若有别人在用的 AutoCAD，既不能强制结束，也不能把命令发到它里面
$script:OwnPids = @()
function Get-LiveAcad { @(Get-Process acad -ErrorAction SilentlyContinue | Where-Object { $_.Threads.Count -gt 0 }) }
function Get-ForeignAcad { @(Get-LiveAcad | Where-Object { $_.Id -notin $script:OwnPids }) }

function Get-Acad { try { [Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application.25.1') } catch { $null } }

function Get-AcadFrame {
  $p = (Get-Process acad -ErrorAction SilentlyContinue | Where-Object { $_.Threads.Count -gt 0 }) | Select-Object -First 1
  if (-not $p) { throw 'AutoCAD 未运行' }
  $h = [PbWin]::Frame([uint32]$p.Id)
  if ($h -eq [IntPtr]::Zero) { $h = $p.MainWindowHandle }
  return $h
}

function Test-AcadIdle { try { return (Get-Acad).GetAcadState().IsQuiescent } catch { return $false } }

function Wait-AcadIdle([int]$Sec = 60) {
  for ($i = 0; $i -lt $Sec * 2; $i++) { if (Test-AcadIdle) { return $true }; Start-Sleep -Milliseconds 500 }
  return $false
}

# 等 AutoCAD 真正空闲：IsQuiescent 在后台加载的间隙也为真，仅凭它判断会在刚启动、刚开项目时就发命令。
# 先固定等 MinSec 秒，再要求 acad 进程 CPU 连续 QuietSec 秒几乎不增长（每 2 s 增量 < 0.15 s），最长等 MaxSec 秒
function Wait-AcadSettled([int]$MinSec = 0, [int]$MaxSec = 150, [int]$QuietSec = 10) {
  if ($MinSec -gt 0) { Start-Sleep $MinSec }
  $p = Get-Process acad -ErrorAction SilentlyContinue | Where-Object { $_.Threads.Count -gt 0 } | Select-Object -First 1
  if (-not $p) { return '无 AutoCAD 进程' }
  $prev = $p.TotalProcessorTime.TotalSeconds; $quiet = 0; $t = 0
  while ($t -lt $MaxSec) {
    Start-Sleep 2; $t += 2; $p.Refresh()
    $cur = $p.TotalProcessorTime.TotalSeconds
    if (($cur - $prev) -lt 0.15) { $quiet += 2 } else { $quiet = 0 }
    $prev = $cur
    if ($quiet -ge $QuietSec) { return "空闲等待 $($MinSec + $t) s" }
  }
  return "空闲等待超过 $MaxSec s，继续"
}

function Send-AcadText([string]$Text) { [PbWin]::Send((Get-AcadFrame), $Text) }

function Get-AcadDialogs([string]$Click) {
  $p = (Get-Process acad -ErrorAction SilentlyContinue | Where-Object { $_.Threads.Count -gt 0 }) | Select-Object -First 1
  if (-not $p) { return }
  foreach ($d in [PbWin]::Dlgs([uint32]$p.Id)) {
    [PbWin]::Describe($d)
    if ($Click -and [PbWin]::ClickBtn($d, $Click)) { "  已点击 $Click" }
  }
}

function Close-RecoveryPanel {
  $p = (Get-Process acad -ErrorAction SilentlyContinue | Where-Object { $_.Threads.Count -gt 0 }) | Select-Object -First 1
  if ($p) { foreach ($d in [PbWin]::Dlgs([uint32]$p.Id)) { if ([PbWin]::Describe($d) -like '图形修复*') { $null = [PbWin]::ClickBtn($d, 'Close'); '已关闭启动时的图形修复面板' } } }
}

# 发送前：等空闲（忙则 ESC 一次再等），并留 1.5 s 稳定时间（连续命令时新命令可能被吞）
function Ready-Acad {
  if (-not (Wait-AcadIdle 30)) { Send-AcadText $script:Esc; Start-Sleep 1; if (-not (Wait-AcadIdle 30)) { throw 'AutoCAD 忙（可能有对话框），请检查' } }
  Start-Sleep -Milliseconds 1500
}

function Invoke-PbLoad {
  Ready-Acad
  $dll = "$script:Root\bin\loader\PidBotLoader.dll".Replace('\', '/')
  Send-AcadText "$script:Esc(setq pidbot_sl (getvar `"SECURELOAD`")) (setvar `"SECURELOAD`" 0) (command `"_.NETLOAD`" `"$dll`") (setvar `"SECURELOAD`" pidbot_sl) (princ) "
  Start-Sleep 2; $null = Wait-AcadIdle 60; '加载器已 NETLOAD'
}

# 发送 PB/PBS 命令，等动词写出 logs\<verb>.log 后返回其内容；超时返回“超时：…”
function Invoke-PbVerb([string]$Verb, [string]$Arg = '-', [int]$TimeoutSec = 600) {
  Ready-Acad
  $log = Join-Path "$script:Root\logs" "$($Verb.ToLower()).log"
  $t0 = if (Test-Path -LiteralPath $log) { (Get-Item -LiteralPath $log).LastWriteTime } else { [datetime]::MinValue }
  $cmd = if ($script:SessionVerbs -contains $Verb.ToLower()) { 'PBS' } else { 'PB' }
  Send-AcadText "$script:Esc$cmd`n$Verb`n$Arg`n"
  $deadline = (Get-Date).AddSeconds($TimeoutSec)
  $n = 0
  while (-not ((Test-Path -LiteralPath $log) -and (Get-Item -LiteralPath $log).LastWriteTime -gt $t0) -and (Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 300
    $p = (Get-Process acad -ErrorAction SilentlyContinue | Where-Object { $_.Threads.Count -gt 0 }) | Select-Object -First 1
    if (-not $p) { throw "AutoCAD 进程已退出（$Verb 未完成）" }   # 闪退时不等满超时
    # 致命错误对话框（“AutoCAD 错误中断”“致命错误”）出现时进程仍在，但命令不会再完成：立即返回，由调用方按偶发故障处理
    if ((++$n % 10) -eq 0) {
      foreach ($d in [PbWin]::Dlgs([uint32]$p.Id)) { $t = [PbWin]::Describe($d); if ($t -match '错误中断|致命错误|FATAL ERROR') { throw "AutoCAD 致命错误（$Verb）：$t" } }
    }
  }
  # 会话级命令（切换文档）之后 AutoCAD 不会自行回到空闲：日志写出即完成，发 ESC 结束残留命令
  if ($cmd -eq 'PBS') { Start-Sleep 1; Send-AcadText $script:Esc; $null = Wait-AcadIdle 15 } else { Start-Sleep 1; $null = Wait-AcadIdle 60 }
  if ((Test-Path -LiteralPath $log) -and (Get-Item -LiteralPath $log).LastWriteTime -gt $t0) { Get-Content -LiteralPath $log -Encoding UTF8 } else { "超时：未生成新日志 $log" }
}

function Invoke-PbAnno([string]$Lsp) {
  $lines = @(Get-Content -LiteralPath $Lsp -Encoding UTF8 | Where-Object { $_ -match '^\(command' })
  if ($lines.Count -eq 0) { return '已发送标注 0 条' }
  Ready-Acad
  foreach ($l in $lines) { Send-AcadText "$l`n"; Start-Sleep -Milliseconds 400; $null = Wait-AcadIdle 20 }
  "已发送标注 $($lines.Count) 条"
}

function Set-RecoveryMode([int]$Mode) { $a = Get-Acad; if ($a) { $a.ActiveDocument.SetVariable('RECOVERYMODE', $Mode); "RECOVERYMODE=$Mode" } }

# 关闭全部文档（不保存，调用前须已 QSAVE）后退出；超时强制结束
function Stop-Acad([int]$WaitSec = 30, [switch]$All) {
  # 默认只结束自己启动的 AutoCAD；-All 才处理机器上全部实例（仅供人工明确要求时使用）
  if (-not $All -and $script:OwnPids.Count -eq 0) { return '无自启 AutoCAD，未处理' }
  $mine = { if ($All) { Get-LiveAcad } else { @(Get-LiveAcad | Where-Object { $_.Id -in $script:OwnPids }) } }
  $a = Get-Acad
  if ($a -and ($All -or @(& $mine).Count -gt 0)) {
    try { $a.ActiveDocument.SetVariable('RECOVERYMODE', 2) } catch {}   # 恢复默认，不影响平时手工使用；自动启动时再设 1
    try { foreach ($d in @($a.Documents)) { try { $d.Close($false) } catch {} } } catch {}
    try { $a.Quit() } catch {}
  }
  for ($i = 0; $i -lt $WaitSec -and @(& $mine).Count -gt 0; $i++) { Start-Sleep 1 }
  $left = @(& $mine)
  if ($left.Count -gt 0) { $left | Stop-Process -Force; Start-Sleep 3; $r = 'acad 已强制结束' } else { $r = 'acad 已退出' }
  if (-not $All) { $script:OwnPids = @() }
  return $r
}

# 启动 Plant 3D（/t 带模板直接建图，避开“开始”选项卡上 Documents.Add 无效），加载 PidBot，可选打开项目。
# 失败抛异常；成功输出含“AutoCAD 就绪”“当前项目”的行。
function Start-Acad([string]$Project) {
  $sw = [Diagnostics.Stopwatch]::StartNew()
  $foreign = @(Get-ForeignAcad)
  if ($foreign.Count -gt 0 -and $env:PB_ALLOW_FOREIGN -ne '1') {
    $d = ($foreign | ForEach-Object { "PID $($_.Id) [$($_.MainWindowTitle)]" }) -join '；'
    throw "检测到不是本脚本启动的 AutoCAD（$d）。为避免误杀正在使用的图纸、把命令发到别人的会话，已停止；请先保存并关闭它们后重试"
  }
  $a = $null
  for ($attempt = 1; $attempt -le 2; $attempt++) {
    if (-not ((Get-Process acad -ErrorAction SilentlyContinue | Where-Object { $_.Threads.Count -gt 0 }))) {
      Start-Process -FilePath $script:Exe -ArgumentList '/product', 'PLNT3D', '/language', '"zh-CN"', '/t', "`"$script:Tpl`""
    }
    $a = $null
    $script:OwnPids = @(Get-LiveAcad | ForEach-Object { $_.Id })   # 此刻没有外来实例，现存的都是自己启动的
    for ($i = 0; $i -lt 240; $i++) { Start-Sleep 1; $a = Get-Acad; if ($a) { try { if ($a.GetAcadState().IsQuiescent) { break } } catch {} } }
    if (-not $a) { throw 'AutoCAD 启动超时' }
    for ($k = 0; $k -lt 24 -and $a.Documents.Count -eq 0; $k++) { Close-RecoveryPanel; try { $null = $a.Documents.Add() } catch {}; Start-Sleep 5 }
    if ($a.Documents.Count -gt 0) { break }
    Get-AcadDialogs | ForEach-Object { '对话框: ' + $_ }
    if ($attempt -eq 1) { '第 1 次启动后无文档，强制结束并重新启动'; Get-LiveAcad | Where-Object { $_.Id -in $script:OwnPids } | Stop-Process -Force; Start-Sleep 5 }
  }
  if ($a.Documents.Count -eq 0) { throw 'AutoCAD 启动后无法新建空白图纸' }
  # 退出常需强制结束，下次启动会弹“图形修复”面板吞命令：批量期间 RECOVERYMODE=1，结束后 Set-RecoveryMode 2
  try { $a.ActiveDocument.SetVariable('RECOVERYMODE', 1) } catch {}
  Close-RecoveryPanel
  $t1 = [int]$sw.Elapsed.TotalSeconds
  "AutoCAD 就绪，文档数 $($a.Documents.Count)"
  Invoke-PbLoad
  $t2 = [int]$sw.Elapsed.TotalSeconds
  if ($Project) {
    $r = Invoke-PbVerb openproject $Project 120
    $r | Select-String '当前项目|错误' | ForEach-Object { $_.Line }
    if (-not ($r -match '当前项目')) { throw "打开项目失败: $Project" }
  }
  # 刚启动/刚开项目就发命令，失败率明显更高（2026-10-16 实验）：默认先等 30 s 并要求 CPU 静默；PB_SETTLE_SEC=0 可关闭
  $settle = if ($env:PB_SETTLE_SEC -ne $null -and $env:PB_SETTLE_SEC -ne '') { [int]$env:PB_SETTLE_SEC } else { 30 }
  if ($settle -gt 0) { Wait-AcadSettled $settle | ForEach-Object { "  $_" } }
  "启动耗时：进程就绪 $t1 s，加载 PidBot $($t2 - $t1) s，打开项目 $([int]$sw.Elapsed.TotalSeconds - $t2) s"
}

Export-ModuleMember -Function Get-LiveAcad, Get-ForeignAcad, Wait-AcadSettled, Get-Acad, Get-AcadFrame, Test-AcadIdle, Wait-AcadIdle, Send-AcadText, Get-AcadDialogs, Close-RecoveryPanel, Invoke-PbLoad, Invoke-PbVerb, Invoke-PbAnno, Set-RecoveryMode, Stop-Acad, Start-Acad






