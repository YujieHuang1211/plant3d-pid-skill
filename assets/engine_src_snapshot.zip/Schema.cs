// 项目数据模型（ProcessPower.dcf）配置
//   schema dump:<表名,...>   列出表的继承、属性、列及列属性
//   schema <json>            按 JSON 新增类、类属性、图纸属性、项目属性（已存在则跳过），最后 AcceptSchemaChanges
// JSON：
// {
//   "classes":  [{"name":"MassFlowController","base":"InlineInstruments","display":"质量流量控制器",
//                 "attrs":{"GraphicalStyleName":["MFC Style","PnPGraphical"]}}],
//   "columns":  [{"table":"EngineeringItems","name":"Supplier","display":"供货方","len":64}],
//   "drawing":  [{"name":"Revision","display":"版次","category":"General","len":16}],
//   "project":  [{"name":"Project_Data_Designer","display":"设计单位","category":"Project_Data","prop":"Designer","len":128}]
// }
using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using Autodesk.ProcessPower.DataObjects;
using Autodesk.ProcessPower.PlantInstance;

namespace PidBot
{
    public static class Schema
    {
        static void L(string s) => Entry.L(s);

        public static void Run(string arg)
        {
            var dlm = PlantApplication.ProjectPart("PnId").DataLinksManager;
            var pdb = dlm.GetPnPDatabase();
            if (arg.StartsWith("dump:")) { foreach (var t in arg.Substring(5).Split(',')) Dump(pdb, t.Trim()); return; }

            using var js = JsonDocument.Parse(File.ReadAllText(arg), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
            var root = js.RootElement;
            int added = 0;

            if (root.TryGetProperty("classes", out var classes))
                foreach (var c in classes.EnumerateArray())
                {
                    string name = c.GetProperty("name").GetString();
                    var t = Tab(pdb, name);
                    if (t == null)
                    {
                        var bt = Tab(pdb, c.GetProperty("base").GetString()) ?? throw new ArgumentException("基类不存在: " + c.GetProperty("base").GetString());
                        t = new PnPTable(name, bt, false);
                        pdb.Tables.Add(t);
                        added++;
                        L($"新增类 {name} : {bt.Name}");
                    }
                    else L($"类已存在 {name}");
                    t.SetTableAttribute("DisplayName", c.GetProperty("display").GetString(), "PnPClassDisplayName");
                    if (c.TryGetProperty("attrs", out var at))
                        foreach (var a in at.EnumerateObject())
                            t.SetTableAttribute(a.Name, a.Value[0].GetString(), a.Value[1].GetString());
                }

            void AddCol(string table, JsonElement c, Action<PnPTable, string> attrs)
            {
                var t = Tab(pdb, table) ?? throw new ArgumentException("表不存在: " + table);
                string name = c.GetProperty("name").GetString();
                if (!HasCol(t, name))
                {
                    int len = c.TryGetProperty("len", out var l) ? l.GetInt32() : 64;
                    try { t.Columns.Add(new PnPColumn(name, typeof(string), len)); }
                    catch (PnPException ex) { L($"跳过列 {table}.{name}: {ex.Message}"); return; }
                    added++;
                    L($"新增列 {table}.{name}");
                }
                else L($"列已存在 {table}.{name}");
                t.SetColumnAttribute(name, "DISPLAYNAME", c.GetProperty("display").GetString());
                attrs?.Invoke(t, name);
            }

            if (root.TryGetProperty("columns", out var cols))
                foreach (var c in cols.EnumerateArray()) AddCol(c.GetProperty("table").GetString(), c, null);
            if (root.TryGetProperty("drawing", out var dcols))
                foreach (var c in dcols.EnumerateArray())
                    AddCol("PnPDrawings", c, (t, n) =>
                    {
                        t.SetColumnAttribute(n, "DRAWINGCATEGORY", c.TryGetProperty("category", out var g) ? g.GetString() : "General");
                        t.SetColumnAttribute(n, "DRAWINGPROPERTY", n);
                    });
            if (root.TryGetProperty("project", out var pcols))
                foreach (var c in pcols.EnumerateArray())
                    AddCol("PnPProject", c, (t, n) =>
                    {
                        t.SetColumnAttribute(n, "PROJECTCATEGORY", c.GetProperty("category").GetString());
                        t.SetColumnAttribute(n, "PROJECTPROPERTY", c.GetProperty("prop").GetString());
                    });

            pdb.AcceptSchemaChanges();
            L($"AcceptSchemaChanges 完成，新增 {added} 项");

            // 选择列表值：{"picklists":{"Services":[["H2","氢气"],...]}}
            if (root.TryGetProperty("picklists", out var pls))
            {
                var tl = pdb.Tables["PnPPicklists"];
                var tv = pdb.Tables["PnPPicklistValues"];
                int pv = 0;
                foreach (var p in pls.EnumerateObject())
                {
                    var lists = tl.Select($"PicklistName='{p.Name}'");
                    if (lists.Length == 0) { L($"选择列表不存在 {p.Name}"); continue; }
                    int lid = Convert.ToInt32(lists[0]["PnPID"]);
                    var have = tv.Select($"PicklistId={lid}").Select(r => r["PicklistValue"]?.ToString()).ToHashSet();
                    foreach (var v in p.Value.EnumerateArray())
                    {
                        string val = v[0].GetString();
                        if (have.Contains(val)) continue;
                        var row = tv.NewRow();
                        row["PicklistValue"] = val;
                        row["PicklistId"] = lid;
                        row["PicklistValueDescription"] = v.GetArrayLength() > 1 ? v[1].GetString() : "";
                        tv.Rows.Add(row);
                        pv++;
                    }
                }
                try { dlm.AcceptMetadataChanges(); pdb.AcceptChanges(); L("AcceptMetadataChanges/AcceptChanges 完成"); } catch (System.Exception ex) { L("提交失败: " + ex.Message); }
                L($"新增选择列表值 {pv} 个");
            }
        }

        static PnPTable Tab(PnPDatabase pdb, string name) { try { return pdb.Tables[name]; } catch { return null; } }
        static bool HasCol(PnPTable t, string name) { try { return t.AllColumns[name] != null; } catch { return false; } }

        static void Dump(PnPDatabase pdb, string name)
        {
            var t = Tab(pdb, name);
            if (t == null) { L($"## {name} 不存在"); return; }
            L($"## {name} base={t.BaseTableName} abstract={t.IsAbstract} derived={string.Join(",", t.DerivedTables.Cast<string>())}");
            foreach (string a in t.GetTableAttributeNamesLocal()) L($"   attr {a}={t.GetTableAttributeValueLocal(a)} ({t.GetTableAttributeTypeLocal(a)})");
            foreach (PnPColumn c in t.Columns)
            {
                var ca = string.Join("; ", t.GetColumnAttributeNamesLocal(c.Name).Cast<string>().Select(x => x + "=" + t.GetColumnAttribute(c.Name, x)));
                L($"   col {c.Name} | {ca}");
            }
        }
    }
}
