﻿param([int]$Code=27)
Add-Type -TypeDefinition @"
using System; using System.Runtime.InteropServices;
public class CD2 {
 [StructLayout(LayoutKind.Sequential)] public struct COPYDATASTRUCT { public IntPtr dwData; public int cbData; public IntPtr lpData; }
 [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr SendMessage(IntPtr h, int msg, IntPtr w, ref COPYDATASTRUCT cds);
 public static void Send(IntPtr h, string s){ var p=Marshal.StringToHGlobalUni(s); var c=new COPYDATASTRUCT{ dwData=(IntPtr)1, cbData=(s.Length+1)*2, lpData=p }; SendMessage(h,0x004A,IntPtr.Zero,ref c); Marshal.FreeHGlobal(p);} }
"@
[CD2]::Send((Get-Process acad).MainWindowHandle, [string][char]$Code + [string][char]$Code)