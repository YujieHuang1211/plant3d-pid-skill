// PidBot 加载器：稳定的命令入口，核心逻辑热加载（改核心不必重启 AutoCAD）
//   PB  <动词> <参数>   文档上下文（绘图、查询、出图）
//   PBS <动词> <参数>   会话上下文（新建/打开项目、新建图纸）
// 核心程序集：_PidBot\bin\core\PidBot.Core.dll，入口 PidBot.Entry.Run(string verb, string arg)
using System;
using System.IO;
using System.Reflection;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;

[assembly: CommandClass(typeof(PidBotLoader.LoaderCommands))]

namespace PidBotLoader
{
    public class LoaderCommands
    {
        const string CorePath = @"E:\05p_id图绘制中心\_PidBot\bin\core\PidBot.Core.dll";
        static Assembly _core;
        static DateTime _stamp;

        [CommandMethod("PB")]
        public void Pb() => Dispatch();

        [CommandMethod("PBS", CommandFlags.Session)]
        public void Pbs() => Dispatch();

        static void Dispatch()
        {
            var ed = AcApp.DocumentManager.MdiActiveDocument.Editor;
            string verb = Ask(ed, "动词");
            if (verb == null) return;
            string arg = Ask(ed, "参数");
            if (arg == "-") arg = "";
            try
            {
                var t = File.GetLastWriteTimeUtc(CorePath);
                if (_core == null || t != _stamp)
                {
                    _core = Assembly.Load(File.ReadAllBytes(CorePath));
                    _stamp = t;
                    ed.WriteMessage($"\n[PidBot] 已加载核心 {t:HH:mm:ss}");
                }
                _core.GetType("PidBot.Entry", true).GetMethod("Run").Invoke(null, new object[] { verb, arg });
            }
            catch (System.Exception ex)
            {
                ed.WriteMessage("\n[PidBot] 加载器错误: " + (ex.InnerException ?? ex));
            }
        }

        static string Ask(Editor ed, string p)
        {
            var r = ed.GetString(new PromptStringOptions("\n" + p + ": ") { AllowSpaces = true });
            return r.Status == PromptStatus.OK ? r.StringResult.Trim().Trim('"') : null;
        }
    }
}
