// 连接关系核查：导出 P&ID 关系表（线-内联件、线-起止对象、线-管嘴、跨图连接器、线组归属）
//   conn [表名,...]   默认导出全部 P&ID 关系表；每行列出关系两端对象的类别与位号
using System;
using System.Linq;
using Autodesk.ProcessPower.DataObjects;
using Autodesk.ProcessPower.PlantInstance;

namespace PidBot
{
    public static class Verify
    {
        static void L(string s) => Entry.L(s);

        static readonly string[] RelTables =
        {
            "LineInlineAsset", "LineStartAsset", "LineEndAsset", "LineNozzle", "AssetOwnership",
            "LineOffPageConnector", "PipeLineGroupRelationship", "SignalLineGroupRelationship", "AnnotationRelationship", "AssetNonEngineeringRelationship"
        };

        public static void Conn(string arg)
        {
            var dlm = PlantApplication.ProjectPart("PnId").DataLinksManager;
            var pdb = dlm.GetPnPDatabase();
            var tables = string.IsNullOrWhiteSpace(arg) ? RelTables : arg.Split(',').Select(s => s.Trim()).ToArray();
            string Desc(object id)
            {
                try
                {
                    int rid = Convert.ToInt32(id);
                    string cls = dlm.GetObjectClassname(rid);
                    string tag = "";
                    try { tag = dlm.GetAllProperties(rid, true).FirstOrDefault(p => p.Key == "Tag").Value; } catch { }
                    return $"{rid}:{cls}:{tag}";
                }
                catch { return id?.ToString(); }
            }
            foreach (var tn in tables)
            {
                PnPTable t;
                try { t = pdb.Tables[tn]; } catch { L($"## {tn} 不存在"); continue; }
                var rows = t.Select();
                var cols = t.AllColumns.Cast<PnPColumn>().Select(c => c.Name).Where(n => !n.StartsWith("PnP")).ToList();
                L($"## {tn} 行数={rows.Length} 列={string.Join(",", cols)}");
                foreach (var r in rows)
                    L("   " + string.Join(" | ", cols.Select(c => $"{c}={(c.EndsWith("Id") || c.StartsWith("Line") || c.StartsWith("Asset") || c.StartsWith("Owner") ? Desc(r[c]) : r[c])}")));
            }
        }
    }
}
