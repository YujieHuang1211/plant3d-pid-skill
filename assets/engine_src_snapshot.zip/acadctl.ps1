﻿# AutoCAD 进程控制（Windows PowerShell 5），兼容旧调用的薄封装；实际逻辑在 pidbot.psm1
#   -Dialogs [-Click OK]  列出（并点击）AutoCAD 对话框
#   -Restart [-Project]   启动 Plant 3D、加载 PidBot、打开项目
#   -CloseDoc <文件名>    通过 COM 关闭（不保存）指定文档；PidBot 命令内部不要关闭文档
#   -Quit                 关闭全部文档后退出，超时强制结束
#   -RestoreRecovery      RECOVERYMODE 恢复为 2
param([switch]$Dialogs, [string]$Click, [switch]$Restart, [string]$Project, [string]$CloseDoc, [switch]$Quit, [switch]$RestoreRecovery)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'pidbot.psm1') -DisableNameChecking
if ($Dialogs) { if (-not (Get-Process acad -ErrorAction SilentlyContinue)) { 'acad 未运行' } else { Get-AcadDialogs $Click } }
if ($CloseDoc) {
  $a = Get-Acad; if (-not $a) { throw 'AutoCAD 不可用' }
  foreach ($d in @($a.Documents)) { if ([IO.Path]::GetFileName($d.FullName) -eq $CloseDoc -or $d.Name -eq $CloseDoc) { $d.Close($false); "已关闭 $CloseDoc" } }
}
if ($RestoreRecovery) { Set-RecoveryMode 2 }
if ($Quit) { Stop-Acad }
if ($Restart) { Start-Acad $Project }

