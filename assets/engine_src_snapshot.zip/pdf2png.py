# 用法: python pdf2png.py <pdf> <png> [dpi] [clip x0,y0,x1,y1 (0-1 相对坐标)]
import sys, fitz
pdf, png = sys.argv[1], sys.argv[2]
dpi = int(sys.argv[3]) if len(sys.argv) > 3 else 100
page = fitz.open(pdf)[0]
clip = None
if len(sys.argv) > 4:
    x0, y0, x1, y1 = map(float, sys.argv[4].split(','))
    r = page.rect
    clip = fitz.Rect(r.x0 + x0 * r.width, r.y0 + y0 * r.height, r.x0 + x1 * r.width, r.y0 + y1 * r.height)
page.get_pixmap(dpi=dpi, clip=clip).save(png)
print(png)
