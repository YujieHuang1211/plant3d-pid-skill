// 项目库配置：API 反射查询、符号库样式清单
//   reflect <正则>        在已加载的 Plant/AutoCAD 程序集中列出名称匹配的类型及其公共成员
//   stylesof <dwg路径>    列出符号库 DWG 中的全部 P&ID 样式：键名、类别、块名、块尺寸
using System;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using Autodesk.AutoCAD.DatabaseServices;

namespace PidBot
{
    public static class Library
    {
        static void L(string s) => Entry.L(s);

        public static void Reflect(string pattern)
        {
            var rx = new Regex(pattern, RegexOptions.IgnoreCase);
            var asms = AppDomain.CurrentDomain.GetAssemblies()
                .Where(a => { var n = a.GetName().Name; return n.StartsWith("PnP") || n.StartsWith("PnI") || n.StartsWith("Pn") || n.StartsWith("Ac") || n.StartsWith("acdb") || n.StartsWith("acmgd") || n.StartsWith("accore"); });
            foreach (var a in asms)
            {
                Type[] types;
                try { types = a.GetTypes(); } catch (ReflectionTypeLoadException ex) { types = ex.Types.Where(t => t != null).ToArray(); } catch { continue; }
                foreach (var t in types.Where(t => t.IsPublic && rx.IsMatch(t.FullName ?? "")))
                {
                    L($"## {a.GetName().Name} :: {t.FullName}" + (t.BaseType != null ? " : " + t.BaseType.Name : ""));
                    var bf = BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
                    foreach (var c in t.GetConstructors()) L("   ctor(" + Pars(c.GetParameters()) + ")");
                    foreach (var p in t.GetProperties(bf)) L($"   prop {p.PropertyType.Name} {p.Name} {(p.CanWrite ? "{get;set;}" : "{get;}")}");
                    foreach (var m in t.GetMethods(bf).Where(m => !m.IsSpecialName))
                        L($"   {(m.IsStatic ? "static " : "")}{m.ReturnType.Name} {m.Name}({Pars(m.GetParameters())})");
                    if (t.IsEnum) L("   enum: " + string.Join(",", Enum.GetNames(t)));
                }
            }
        }

        // ---------------------------------------------------------------- 标签格式（存于项目符号库 DWG 的 TagFormat 对象）
        // tagformats            列出
        // tagformats <json>     修改：[{"name":"..","format":"..","desc":".."}]，保存符号库
        public static void TagFormats(string arg)
        {
            string sym = Autodesk.ProcessPower.PlantInstance.PlantApplication.ProjectPart("PnId").SymbolAndStyleCacheFile;
            bool edit = !string.IsNullOrWhiteSpace(arg);
            var edits = new System.Collections.Generic.Dictionary<string, (string fmt, string desc)>();
            if (edit)
            {
                using var js = System.Text.Json.JsonDocument.Parse(System.IO.File.ReadAllText(arg));
                foreach (var e in js.RootElement.EnumerateArray())
                    edits[e.GetProperty("name").GetString()] = (e.GetProperty("format").GetString(),
                        e.TryGetProperty("desc", out var d) ? d.GetString() : null);
            }
            using var db = new Database(false, true);
            db.ReadDwgFile(sym, FileOpenMode.OpenForReadAndAllShare, true, null);
            if (edit) db.CloseInput(true);   // 全部读入并释放文件，才能回存同名文件
            int n = 0, changed = 0;
            using (var tr = db.TransactionManager.StartTransaction())
            {
                foreach (var id in AllDictObjects(tr, db.NamedObjectsDictionaryId, 0))
                {
                    if (!(tr.GetObject(id, OpenMode.ForRead) is Autodesk.ProcessPower.TagFormats.TagFormat tf)) continue;
                    n++;
                    if (edits.TryGetValue(tf.Name, out var v))
                    {
                        tf.UpgradeOpen();
                        tf.FormatString = v.fmt;
                        if (v.desc != null) tf.Description = v.desc;
                        changed++;
                    }
                    L($"TagFormat\t{tf.Name}\tclass={tf.ClassName}\tflag={tf.FlagValue}\tformat={tf.FormatString}\tdesc={tf.Description}");
                }
                tr.Commit();
            }
            if (edit)
            {
                db.SaveAs(sym, DwgVersion.Current);
                L($"已修改 {changed}/{edits.Count} 个标签格式并保存 {sym}");
            }
            L($"共 {n} 个标签格式");
        }

        static System.Collections.Generic.IEnumerable<ObjectId> AllDictObjects(Transaction tr, ObjectId dictId, int depth)
        {
            if (depth > 6 || !(tr.GetObject(dictId, OpenMode.ForRead) is DBDictionary dict)) yield break;
            foreach (DBDictionaryEntry e in dict)
            {
                if (e.Value.ObjectClass.Name == "AcDbDictionary")
                {
                    foreach (var x in AllDictObjects(tr, e.Value, depth + 1)) yield return x;
                }
                else yield return e.Value;
            }
        }

        // ---------------------------------------------------------------- 外部 DWG/DWT 结构：布局、页面设置、各空间实体、文字样式、图层
        public static void DwgInfo(string path)
        {
            using var db = new Database(false, true);
            db.ReadDwgFile(path, FileOpenMode.OpenForReadAndAllShare, true, null);
            using var tr = db.TransactionManager.StartTransaction();
            L($"INSUNITS={db.Insunits} LIMMIN={db.Limmin} LIMMAX={db.Limmax} LTSCALE={db.Ltscale} PSTYLEMODE={db.PlotStyleMode}");
            var lts = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
            foreach (ObjectId id in lts) { var t = (TextStyleTableRecord)tr.GetObject(id, OpenMode.ForRead); L($"TEXTSTYLE {t.Name} font={t.FileName} big={t.BigFontFileName} h={t.TextSize} w={t.XScale}"); }
            var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            foreach (ObjectId id in lt) { var r = (LayerTableRecord)tr.GetObject(id, OpenMode.ForRead); L($"LAYER {r.Name} color={r.Color.ColorIndex} lw={r.LineWeight} plot={r.IsPlottable}"); }
            foreach (DBDictionaryEntry e in (DBDictionary)tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead))
            {
                var lo = (Layout)tr.GetObject(e.Value, OpenMode.ForRead);
                L($"LAYOUT {lo.LayoutName} tab={lo.TabOrder} dev={lo.PlotConfigurationName} media={lo.CanonicalMediaName} rot={lo.PlotRotation} type={lo.PlotType} ctb={lo.CurrentStyleSheet} scale={lo.CustomPrintScale.Numerator}:{lo.CustomPrintScale.Denominator}");
                var btr = (BlockTableRecord)tr.GetObject(lo.BlockTableRecordId, OpenMode.ForRead);
                var count = new System.Collections.Generic.Dictionary<string, int>();
                foreach (ObjectId id in btr)
                {
                    var en = (Entity)tr.GetObject(id, OpenMode.ForRead);
                    string k = en.GetType().Name + "@" + en.Layer;
                    if (en is BlockReference br)
                    {
                        string ext = ""; try { var x = br.GeometricExtents; ext = $"[{x.MinPoint.X:F1},{x.MinPoint.Y:F1}]-[{x.MaxPoint.X:F1},{x.MaxPoint.Y:F1}]"; } catch { }
                        L($"  {lo.LayoutName}: BLOCK {br.Name} layer={br.Layer} pos={br.Position} scale={br.ScaleFactors.X} {ext}");
                        foreach (ObjectId aid in br.AttributeCollection)
                        {
                            var ar = (AttributeReference)tr.GetObject(aid, OpenMode.ForRead);
                            L($"     ATTR {ar.Tag}={ar.TextString} h={ar.Height} style={ar.TextStyleName}");
                        }
                    }
                    else if (en is Viewport vp) L($"  {lo.LayoutName}: VIEWPORT c={vp.CenterPoint} w={vp.Width} h={vp.Height} vc={vp.ViewCenter} vh={vp.ViewHeight} on={vp.On} num={vp.Number} layer={vp.Layer}");
                    else if (lo.ModelType == false && !(en is MText) && en.GetType().Name != "Line" && en.GetType().Name != "Polyline") L($"  {lo.LayoutName}: {en.GetType().Name} layer={en.Layer}");
                    else if (en is MText mt && !lo.ModelType) L($"  {lo.LayoutName}: MTEXT layer={mt.Layer} at={mt.Location} h={mt.TextHeight} raw={mt.Contents} field={FieldCode(tr, mt)}");
                    count[k] = count.TryGetValue(k, out var c) ? c + 1 : 1;
                }
                foreach (var kv in count) L($"  {lo.LayoutName}: {kv.Key} x{kv.Value}");
            }
            tr.Commit();
        }

        internal static string FieldCode(Transaction tr, DBObject o)
        {
            try
            {
                if (o.ExtensionDictionary.IsNull) return "";
                var xd = (DBDictionary)tr.GetObject(o.ExtensionDictionary, OpenMode.ForRead);
                if (!xd.Contains("ACAD_FIELD")) return "";
                var fd = (DBDictionary)tr.GetObject(xd.GetAt("ACAD_FIELD"), OpenMode.ForRead);
                var sb = new System.Text.StringBuilder();
                foreach (DBDictionaryEntry e in fd)
                    if (tr.GetObject(e.Value, OpenMode.ForRead) is Field f)
                        sb.Append(e.Key + ":" + f.GetFieldCode(FieldCodeFlags.AddMarkers | FieldCodeFlags.FieldCode) + " ");
                return sb.ToString();
            }
            catch (System.Exception ex) { return "ERR " + ex.Message; }
        }

        // ---------------------------------------------------------------- 项目属性 / 当前图纸属性（驱动标题栏字段）
        //   projprops <json>  {"Project_Number":"..","Client_Information_Company_Name":"..",...}
        //   dwgprops  <json>  {"PnID":"P&ID-101","Title":"..","DWG_Title"?..}  写当前图纸在 PnPDrawings 中的行
        public static void ProjProps(string arg)
        {
            var dlm = Autodesk.ProcessPower.PlantInstance.PlantApplication.ProjectPart("PnId").DataLinksManager;
            var pdb = dlm.GetPnPDatabase();
            var row = pdb.Tables["PnPProject"].Select().First();
            SetRow(row, arg);
            pdb.AcceptChanges();
            dlm.AcceptMetadataChanges();
            L("项目属性已写入");
        }

        public static void DwgProps(string arg)
        {
            var doc = Autodesk.AutoCAD.ApplicationServices.Core.Application.DocumentManager.MdiActiveDocument;
            var dlm = Autodesk.ProcessPower.PlantInstance.PlantApplication.ProjectPart("PnId").DataLinksManager;
            var pdb = dlm.GetPnPDatabase();
            string name = System.IO.Path.GetFileName(doc.Name);
            var row = pdb.Tables["PnPDrawings"].Select().FirstOrDefault(r => string.Equals(r["Dwg Name"]?.ToString(), name, StringComparison.OrdinalIgnoreCase))
                      ?? throw new InvalidOperationException("项目中找不到图纸 " + name);
            SetRow(row, arg);
            pdb.AcceptChanges();
            using (doc.LockDocument())
            {
                try { doc.Database.EvaluateFields(); } catch (System.Exception ex) { L("字段刷新: " + ex.Message); }
            }
            L($"图纸属性已写入 {name}");
        }

        static void SetRow(Autodesk.ProcessPower.DataObjects.PnPRow row, string jsonPath)
        {
            using var js = System.Text.Json.JsonDocument.Parse(System.IO.File.ReadAllText(jsonPath));
            row.BeginEdit();
            foreach (var p in js.RootElement.EnumerateObject())
            {
                try { row[p.Name] = p.Value.GetString(); L($"  {p.Name} = {p.Value.GetString()}"); }
                catch (System.Exception ex) { L($"  写入失败 {p.Name}: {ex.Message}"); }
            }
            row.EndEdit();
        }

        // ---------------------------------------------------------------- 符号块解剖：列出样式块内实体（类型、图层、XData 应用名、属性定义）
        //   blockinfo <dwg>|<样式名,...>
        public static void BlockInfo(string arg)
        {
            var parts = arg.Split('|');
            using var db = new Database(false, true);
            db.ReadDwgFile(parts[0], FileOpenMode.OpenForReadAndAllShare, true, null);
            using var tr = db.TransactionManager.StartTransaction();
            var styles = parts[1].Split(',').Select(s => s.Trim()).ToHashSet();
            foreach (var id in AllDictObjects(tr, db.NamedObjectsDictionaryId, 0))
            {
                if (!(tr.GetObject(id, OpenMode.ForRead) is Autodesk.ProcessPower.Styles.Style st) || !styles.Contains(st.Name)) continue;
                L($"## {st.Name} {st.GetType().Name} class={st.ClassName} layerUse={st.UseDatabaseLayer} lw={st.LineWeight} color={st.Color}" +
                  (st is Autodesk.ProcessPower.Styles.AssetStyle a ? $" scale={a.ScaleFactor} scaleOnInsert={a.ScaleOnInsert} join={a.JoinType}" : "") +
                  (st is Autodesk.ProcessPower.Styles.AnnotationStyle an ? $" annScale={an.ScaleFactor}" : ""));
                try { L("   layer=" + ((LayerTableRecord)tr.GetObject(st.LayerId, OpenMode.ForRead)).Name); } catch { }
                if (!st.BlockTableRecord.IsValid) continue;
                var btr = (BlockTableRecord)tr.GetObject(st.BlockTableRecord, OpenMode.ForRead);
                L($"   block={btr.Name} origin={btr.Origin}");
                foreach (ObjectId eid in btr)
                {
                    var en = (Entity)tr.GetObject(eid, OpenMode.ForRead);
                    string ext = ""; try { var x = en.GeometricExtents; ext = $"[{x.MinPoint.X:F3},{x.MinPoint.Y:F3}]-[{x.MaxPoint.X:F3},{x.MaxPoint.Y:F3}]"; } catch { }
                    string xd = "";
                    var rb = en.XData; if (rb != null) xd = " xdata=" + string.Join("|", rb.Cast<TypedValue>().Select(v => v.Value?.ToString()));
                    string ad = en is AttributeDefinition d ? $" ATTDEF tag={d.Tag} h={d.Height} txt={d.TextString} pos=({d.Position.X:F3},{d.Position.Y:F3}) align=({d.AlignmentPoint.X:F3},{d.AlignmentPoint.Y:F3}) just={d.Justify} inv={d.Invisible}" : "";
                    string tx = en is DBText t ? $" text={t.TextString} h={t.Height}" : "";
                    L($"   {en.GetType().Name} layer={en.Layer} {ext}{ad}{tx}{xd}");
                }
            }
            tr.Commit();
        }

        // 在内存中分解指定句柄的实体，列出其图元（排查 Plant 自定义实体自带的文字等）
        public static void Explode(string handles)
        {
            var db = Autodesk.AutoCAD.ApplicationServices.Core.Application.DocumentManager.MdiActiveDocument.Database;
            using var tr = db.TransactionManager.StartTransaction();
            foreach (var h in handles.Split(','))
            {
                var id = db.GetObjectId(false, new Handle(Convert.ToInt64(h.Trim(), 16)), 0);
                var en = (Entity)tr.GetObject(id, OpenMode.ForRead);
                var col = new DBObjectCollection();
                try { en.Explode(col); } catch (System.Exception ex) { L($"{h}: 不能分解 {ex.Message}"); continue; }
                L($"## {h} {en.GetType().Name} → {col.Count} 个图元");
                foreach (DBObject o in col)
                {
                    string d = o.GetType().Name;
                    if (o is DBText t) d += $" text={t.TextString} at={t.Position} h={t.Height}";
                    if (o is MText m) d += $" mtext={m.Contents} at={m.Location}";
                    if (o is BlockReference b) d += $" block={b.Name} at={b.Position}";
                    if (o is Entity e2) { try { var x = e2.GeometricExtents; d += $" [{x.MinPoint.X:F1},{x.MinPoint.Y:F1}]-[{x.MaxPoint.X:F1},{x.MaxPoint.Y:F1}]"; } catch { } }
                    L("   " + d);
                    o.Dispose();
                }
            }
            tr.Commit();
        }

        static string Pars(ParameterInfo[] ps) => string.Join(", ", ps.Select(p => p.ParameterType.Name + " " + p.Name));

        public static void StylesOf(string dwg)
        {
            using var db = new Database(false, true);
            db.ReadDwgFile(dwg, FileOpenMode.OpenForReadAndAllShare, true, null);
            using var tr = db.TransactionManager.StartTransaction();
            int n = 0;
            Walk(tr, db.NamedObjectsDictionaryId, "", 0, ref n);
            tr.Commit();
            L($"共 {n} 个样式");
        }

        static void Walk(Transaction tr, ObjectId dictId, string path, int depth, ref int n)
        {
            if (depth > 5 || !(tr.GetObject(dictId, OpenMode.ForRead) is DBDictionary dict)) return;
            foreach (DBDictionaryEntry e in dict)
            {
                var obj = tr.GetObject(e.Value, OpenMode.ForRead);
                if (obj is DBDictionary) { Walk(tr, e.Value, path + "/" + e.Key, depth + 1, ref n); continue; }
                string cls = obj.GetType().Name;
                string extra = "";
                if (obj is Autodesk.ProcessPower.Styles.AssetStyle st)
                {
                    string bn = "", size = "";
                    try
                    {
                        if (st.BlockTableRecord.IsValid)
                        {
                            var btr = (BlockTableRecord)tr.GetObject(st.BlockTableRecord, OpenMode.ForRead);
                            bn = btr.Name;
                            var ext = new Extents3d(); bool any = false;
                            foreach (ObjectId id in btr)
                                if (tr.GetObject(id, OpenMode.ForRead) is Entity en)
                                    try { ext.AddExtents(en.GeometricExtents); any = true; } catch { }
                            if (any) size = $"{ext.MaxPoint.X - ext.MinPoint.X:F2}x{ext.MaxPoint.Y - ext.MinPoint.Y:F2}";
                        }
                    }
                    catch { }
                    extra = $"\tclass={st.ClassName}\tblock={bn}\tsize={size}\tscale={st.ScaleFactor:F2}\tdesc={st.Description}";
                }
                else if (!cls.Contains("Style")) continue;
                n++;
                L($"{cls}\t{path}\t{e.Key}{extra}");
            }
        }
    }
}
