﻿# 普通图元 DWG 的重开核查（Windows PowerShell 5）：在全新 AutoCAD 会话里重新打开各图，用 info 导出模型空间清单，交 reopen_plain.py 核对。
#   reopen_plain.ps1 -Project <Project.xml> -Specs <普通版 specs 目录> -Sheets "P&ID-101|P&ID-101_xxx.dwg;..." -OutDir <输出目录> [-Profile <配置>]
# 不关闭、不保存、不改动图纸；只结束自己启动的 AutoCAD。用户自己的 AutoCAD 在运行时直接停止。
param([string]$Project, [string]$Specs, [string]$Sheets, [string]$OutDir, [string]$Profile = 'legacy-2026-10',
      [string]$Tools = 'C:\Users\yujie\.claude\skills\plant3d-pid\scripts')
$ErrorActionPreference = 'Stop'
$env:PYTHONIOENCODING = 'utf-8'
Import-Module (Join-Path $PSScriptRoot 'pidbot.psm1') -DisableNameChecking
$log = 'E:\05p_id图绘制中心\_PidBot\logs'
New-Item -ItemType Directory -Force $OutDir | Out-Null
$list = @($Sheets -split ';' | Where-Object { $_.Trim() } | ForEach-Object { $a = $_.Split('|'); [pscustomobject]@{ No = $a[0].Trim(); Dwg = $a[1].Trim() } })
$sw = [Diagnostics.Stopwatch]::StartNew()
function T { '{0,5:N0}s' -f $sw.Elapsed.TotalSeconds }
if (@(Get-ForeignAcad).Count -gt 0) { throw '已有 AutoCAD 在运行，请先保存关闭；引擎不会动不属于它的 AutoCAD' }
"$(T) 启动 AutoCAD"
Start-Acad $Project | Select-String '就绪|当前项目|启动耗时' | ForEach-Object { "  $($_.Line)" }
$fail = 0
try {
  foreach ($s in $list) {
    "$(T) === $($s.No) 重开"
    $r = Invoke-PbVerb opendwg $s.Dwg 120
    if ($r -match '错误|超时') { "  打开失败：$r"; $fail++; continue }
    $null = Invoke-PbVerb info x 180
    $out = Join-Path $OutDir ("reopen_{0}.info.log" -f $s.No)
    Copy-Item "$log\info.log" $out -Force
    & python "$Tools\reopen_plain.py" $out $Specs $s.No (Join-Path $OutDir ("reopen_{0}.json" -f $s.No)) $Profile
    if ($LASTEXITCODE -ne 0) { $fail++ }
  }
} finally { $null = Stop-Acad }
"$(T) 重开核查结束，失败 $fail 张"
if ($fail -gt 0) { exit 1 }
