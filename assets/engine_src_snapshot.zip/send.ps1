﻿# 用法: powershell -File send.ps1 -Verb draw [-Arg "参数"] [-Load] [-Anno <lsp文件>]
# 兼容旧调用的薄封装；实际逻辑在 pidbot.psm1（批处理脚本应直接 Import-Module，免去每条命令起子进程）
param([string]$Verb, [string]$Arg = '-', [switch]$Load, [string]$Anno, [int]$TimeoutSec = 600)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'pidbot.psm1') -DisableNameChecking
if ($Load) { Invoke-PbLoad }
if ($Verb) { Invoke-PbVerb $Verb $Arg $TimeoutSec }
if ($Anno) { Invoke-PbAnno $Anno }

