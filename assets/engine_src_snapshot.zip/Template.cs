// GB 图框模板：以 PIP P&ID 模板为底，生成 GB/T 14689 图框 + GB/T 10609.1 标题栏（Plant 字段）+ 上方修订栏
//   mkdwt <json>  {"base":"PIP模板.dwt","out":"输出.dwt","paper":"A3"|"A1","layout":"A3 GB 标题栏"}
// 坐标：图纸空间 1 单位 = 1 mm；视口 1:1，模型空间坐标与图纸坐标一致（模型空间按实际打印尺寸绘图，NTS）。
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.ProcessPower.PlantInstance;

namespace PidBot
{
    public static class Template
    {
        static void L(string s) => Entry.L(s);
        public const string TextStyle = "GB_CN";
        const double TbW = 180, TbH = 56, RevRowH = 7;
        const int RevRows = 3;   // 修订记录行（不含表头）；由 4 改 3，修订栏顶在 89 mm，给图面右下留出位置（P&ID-101 出口连接器）

        public sealed class Paper
        {
            public string Name; public double W, H, A, C; public string Media;
            public double X0 => A; public double Y0 => C; public double X1 => W - C; public double Y1 => H - C;
        }

        public static Paper Get(string name) => name.ToUpperInvariant() switch
        {
            "A1" => new Paper { Name = "A1", W = 841, H = 594, A = 25, C = 10, Media = "ISO_full_bleed_A1_(841.00_x_594.00_MM)" },
            _ => new Paper { Name = "A3", W = 420, H = 297, A = 25, C = 5, Media = "ISO_full_bleed_A3_(420.00_x_297.00_MM)" },
        };

        public static void Make(string arg)
        {
            using var js = JsonDocument.Parse(File.ReadAllText(arg));
            var c = js.RootElement;
            string basePath = c.GetProperty("base").GetString();
            string outPath = c.GetProperty("out").GetString();
            var pp = Get(c.GetProperty("paper").GetString());
            string layoutName = c.TryGetProperty("layout", out var ln) ? ln.GetString() : $"{pp.Name} GB 标题栏";

            using var db = new Database(false, true);
            db.ReadDwgFile(basePath, FileOpenMode.OpenForReadAndAllShare, true, null);
            db.CloseInput(true);
            var prevWdb = Autodesk.AutoCAD.DatabaseServices.HostApplicationServices.WorkingDatabase;
            Autodesk.AutoCAD.DatabaseServices.HostApplicationServices.WorkingDatabase = db;
            try
            {
                using (var tr = db.TransactionManager.StartTransaction())
                {
                    EnsureTextStyle(tr, db);
                    GbTextStyles(tr, db);
                    Layer(tr, db, "图框", 7, LineWeight.LineWeight070, true);
                    Layer(tr, db, "标题栏", 7, LineWeight.LineWeight025, true);
                    Layer(tr, db, "标题栏文字", 7, LineWeight.LineWeight025, true);
                    Layer(tr, db, "视口", 8, LineWeight.LineWeight025, false);
                    Layer(tr, db, "未打印", 41, LineWeight.ByLineWeightDefault, false);
                    Layer(tr, db, "注释", 7, LineWeight.LineWeight025, true);
                    Layer(tr, db, "表格", 7, LineWeight.LineWeight025, true);
                    db.Textstyle = ((TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead))[TextStyle];

                    // 模型空间：清掉 PIP 的可绘区框，换成本图幅的可绘区与标题栏/修订栏禁区（不打印）
                    var ms = (BlockTableRecord)tr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(db), OpenMode.ForWrite);
                    foreach (ObjectId id in ms) { var e = (Entity)tr.GetObject(id, OpenMode.ForWrite); e.Erase(); }
                    Rect(tr, ms, pp.X0, pp.Y0, pp.X1, pp.Y1, "未打印", LineWeight.ByLayer);
                    double ry1 = pp.Y0 + TbH + RevRowH * (RevRows + 1);
                    Rect(tr, ms, pp.X1 - TbW, pp.Y0, pp.X1, ry1, "未打印", LineWeight.ByLayer);
                    db.Limmin = new Point2d(0, 0); db.Limmax = new Point2d(pp.W, pp.H);

                    // 布局：保留第一个图纸布局，改名并清空，其余删除
                    var ld = (DBDictionary)tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead);
                    var paperLayouts = new List<Layout>();
                    foreach (DBDictionaryEntry e in ld) { var lo = (Layout)tr.GetObject(e.Value, OpenMode.ForRead); if (!lo.ModelType) paperLayouts.Add(lo); }
                    var layout = paperLayouts.OrderBy(l => l.TabOrder).First();
                    var lm = LayoutManager.Current;
                    foreach (var other in paperLayouts.Where(l => l.ObjectId != layout.ObjectId)) { other.UpgradeOpen(); other.Erase(); }
                    layout.UpgradeOpen();
                    layout.LayoutName = layoutName;
                    var ps = (BlockTableRecord)tr.GetObject(layout.BlockTableRecordId, OpenMode.ForWrite);
                    // 布局自身的图纸空间视口（GetViewports 第一个）必须保留，否则内容视口不会重生成、打印为空
                    var vps = layout.GetViewports();
                    ObjectId overallId = vps != null && vps.Count > 0 ? vps[0] : ObjectId.Null;
                    if (overallId.IsNull)
                        foreach (ObjectId id in ps) if (tr.GetObject(id, OpenMode.ForRead) is Viewport) { overallId = id; break; }
                    foreach (ObjectId id in ps)
                    {
                        if (id == overallId) continue;
                        ((Entity)tr.GetObject(id, OpenMode.ForWrite)).Erase();
                    }
                    L("保留图纸空间总视口: " + overallId.Handle);

                    // 页面设置：DWG To PDF，GB 图幅，1:1，单色
                    var psv = PlotSettingsValidator.Current;
                    psv.SetPlotConfigurationName(layout, "DWG To PDF.pc3", null);
                    psv.RefreshLists(layout);
                    var media = psv.GetCanonicalMediaNameList(layout).Cast<string>().ToList();
                    psv.SetCanonicalMediaName(layout, media.Contains(pp.Media) ? pp.Media : media.First(m => m.Contains(pp.Name)));
                    psv.SetPlotPaperUnits(layout, PlotPaperUnit.Millimeters);
                    psv.SetPlotRotation(layout, PlotRotation.Degrees000);
                    psv.SetPlotType(layout, Autodesk.AutoCAD.DatabaseServices.PlotType.Layout);
                    psv.SetUseStandardScale(layout, true);
                    psv.SetStdScaleType(layout, StdScaleType.StdScale1To1);
                    try { psv.SetPlotOrigin(layout, new Point2d(0, 0)); } catch { }
                    try { psv.SetCurrentStyleSheet(layout, "monochrome.ctb"); } catch { }
                    layout.PrintLineweights = true;
                    layout.ScaleLineweights = false;

                    // 视口：覆盖内框，1:1
                    var vp = new Viewport
                    {
                        CenterPoint = new Point3d((pp.X0 + pp.X1) / 2, (pp.Y0 + pp.Y1) / 2, 0),
                        Width = pp.X1 - pp.X0, Height = pp.Y1 - pp.Y0, Layer = "视口",
                    };
                    ps.AppendEntity(vp); tr.AddNewlyCreatedDBObject(vp, true);
                    vp.ViewCenter = new Point2d((pp.X0 + pp.X1) / 2, (pp.Y0 + pp.Y1) / 2);
                    vp.ViewHeight = pp.Y1 - pp.Y0;
                    vp.On = true;
                    vp.Locked = true;

                    DrawFrame(tr, ps, pp);
                    DrawTitleBlock(tr, db, ps, pp);
                    tr.Commit();
                }
                // 项目符号库样式固化进模板：复制全部图形样式（覆盖），再按配置统一尺寸/线宽/标注字高
                if (c.TryGetProperty("stylecfg", out var scfg))
                {
                    string sym = PlantApplication.ProjectPart("PnId").SymbolAndStyleCacheFile;
                    using var src = new Database(false, true);
                    src.ReadDwgFile(sym, FileOpenMode.OpenForReadAndAllShare, true, null);
                    var names = new List<string>();
                    using (var tr = src.TransactionManager.StartTransaction())
                    {
                        foreach (var id in StyleLibWalk(tr, src.NamedObjectsDictionaryId, 0))
                            if (tr.GetObject(id, OpenMode.ForRead) is Autodesk.ProcessPower.Styles.Style st && !(st is Autodesk.ProcessPower.Styles.AnnotationStyle)) names.Add(st.Name);
                        tr.Commit();
                    }
                    int ok = 0;
                    foreach (var n in names.Distinct())
                        try { if (Autodesk.ProcessPower.PnIDObjects.ProjectSymbolStyleUtils.CopyStyle(n, src, db).IsValid) ok++; } catch { }
                    using var sj = JsonDocument.Parse(File.ReadAllText(scfg.GetString()), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
                    if (sj.RootElement.TryGetProperty("set", out var sets)) StyleLib.ApplySets(db, sets);
                    L($"模板已固化项目样式 {ok}/{names.Distinct().Count()} 个并应用统一设置");
                }
                // 先存临时文件再覆盖：目标 DWT 可能正被由它新建的图纸引用，原地 SaveAs 会出错甚至致命错误
                string tmp = Path.Combine(Path.GetTempPath(), "pidbot_" + Guid.NewGuid().ToString("N") + ".dwt");
                db.SaveAs(tmp, DwgVersion.Current);
                Directory.CreateDirectory(Path.GetDirectoryName(outPath));
                File.Copy(tmp, outPath, true);
                File.Delete(tmp);
                L($"已生成模板 {outPath}（{pp.Name} {pp.W}×{pp.H}，布局 {layoutName}）");
            }
            finally
            {
                // 恢复为当前活动文档的数据库；不要恢复调用前保存的值——若期间关闭过文档，它可能已释放，恢复后下一步操作致命错误
                var active = Autodesk.AutoCAD.ApplicationServices.Core.Application.DocumentManager.MdiActiveDocument?.Database;
                Autodesk.AutoCAD.DatabaseServices.HostApplicationServices.WorkingDatabase = active ?? prevWdb;
            }
        }

        // ---------------------------------------------------------------- GB/T 14689 图框与对中符号
        static void DrawFrame(Transaction tr, BlockTableRecord ps, Paper p)
        {
            Rect(tr, ps, 0, 0, p.W, p.H, "图框", LineWeight.LineWeight025);           // 图纸边界（细实线）
            Rect(tr, ps, p.X0, p.Y0, p.X1, p.Y1, "图框", LineWeight.LineWeight070);   // 图框线（粗实线）
            double cx = p.W / 2, cy = p.H / 2, k = 5;
            Line(tr, ps, cx, 0, cx, p.Y0 + k, "图框", LineWeight.LineWeight070);
            Line(tr, ps, cx, p.H, cx, p.Y1 - k, "图框", LineWeight.LineWeight070);
            Line(tr, ps, 0, cy, p.X0 + k, cy, "图框", LineWeight.LineWeight070);
            Line(tr, ps, p.W, cy, p.X1 - k, cy, "图框", LineWeight.LineWeight070);
        }

        // ---------------------------------------------------------------- GB/T 10609.1 标题栏（180×56）+ 修订栏
        static void DrawTitleBlock(Transaction tr, Database db, BlockTableRecord ps, Paper p)
        {
            double x0 = p.X1 - TbW, y0 = p.Y0;
            var thin = LineWeight.LineWeight025;
            string D(string prop) => $"%<\\PnID DrawingProperties.General.{prop}>%";
            string P(string cat, string prop) => $"%<\\PnID ProjectDetails.{cat}.{prop}>%";

            // 外框（粗）
            Rect(tr, ps, x0, y0, x0 + TbW, y0 + TbH, "标题栏", LineWeight.LineWeight070);
            // 左区 80 宽：8 行 × 7；列 16/24/16/24
            double lw = 80;
            Line(tr, ps, x0 + lw, y0, x0 + lw, y0 + TbH, "标题栏", LineWeight.LineWeight050);
            for (int i = 1; i < 8; i++) Line(tr, ps, x0, y0 + 7 * i, x0 + lw, y0 + 7 * i, "标题栏", i == 4 ? LineWeight.LineWeight050 : thin);
            foreach (double cxv in new[] { 16.0, 40.0, 56.0 }) Line(tr, ps, x0 + cxv, y0 + 7, x0 + cxv, y0 + TbH, "标题栏", thin);
            Line(tr, ps, x0 + 40, y0, x0 + 40, y0 + 7, "标题栏", thin);

            // 签署区（上四行）：职责 | 姓名 | 签名 | 日期
            string[] roles = { "设计", "校核", "审核", "批准" };
            string[] who = { D("Author"), D("Checker"), D("Reviewer"), D("Approver") };
            for (int i = 0; i < 4; i++)
            {
                double ry = y0 + TbH - 7 * (i + 1);
                Text(tr, db, ps, x0 + 8, ry + 3.5, roles[i], 3.5, AttachmentPoint.MiddleCenter);
                Field(tr, db, ps, x0 + 28, ry + 3.5, who[i], 3, AttachmentPoint.MiddleCenter);
                if (i == 0) Field(tr, db, ps, x0 + 68, ry + 3.5, D("IssueDate"), 3, AttachmentPoint.MiddleCenter);
            }
            // 签署区表头说明写在左上角外？——不加表头，职责列即说明；“签名/日期”两列空白供手签
            // 下四行：阶段|版次；比例|图幅；编号|区域；共 张 第 张
            void Pair(int row, string l1, string v1, string l2, string v2, bool f1, bool f2)
            {
                double ry = y0 + 7 * row;
                Text(tr, db, ps, x0 + 8, ry + 3.5, l1, 3.5, AttachmentPoint.MiddleCenter);
                if (f1) Field(tr, db, ps, x0 + 28, ry + 3.5, v1, 3, AttachmentPoint.MiddleCenter); else Text(tr, db, ps, x0 + 28, ry + 3.5, v1, 3, AttachmentPoint.MiddleCenter);
                Text(tr, db, ps, x0 + 48, ry + 3.5, l2, 3.5, AttachmentPoint.MiddleCenter);
                if (f2) Field(tr, db, ps, x0 + 68, ry + 3.5, v2, 3, AttachmentPoint.MiddleCenter); else Text(tr, db, ps, x0 + 68, ry + 3.5, v2, 3, AttachmentPoint.MiddleCenter);
            }
            Pair(3, "阶段", D("Stage"), "版次", D("Revision"), true, true);
            Pair(2, "比例", D("Scale"), "图幅", p.Name, true, false);
            Pair(1, "编号", P("General", "Project_Number"), "区域", D("Area"), true, true);
            // 第 0 行：共 X 张 第 Y 张
            Text(tr, db, ps, x0 + 6, y0 + 3.5, "共", 3.5, AttachmentPoint.MiddleCenter);
            Field(tr, db, ps, x0 + 14, y0 + 3.5, D("SheetTotal"), 3, AttachmentPoint.MiddleCenter);
            Text(tr, db, ps, x0 + 22, y0 + 3.5, "张", 3.5, AttachmentPoint.MiddleCenter);
            Text(tr, db, ps, x0 + 46, y0 + 3.5, "第", 3.5, AttachmentPoint.MiddleCenter);
            Field(tr, db, ps, x0 + 56, y0 + 3.5, D("SheetNo"), 3, AttachmentPoint.MiddleCenter);
            Text(tr, db, ps, x0 + 66, y0 + 3.5, "张", 3.5, AttachmentPoint.MiddleCenter);

            // 右区 100 宽：设计单位(12) | 项目名称(14) | 图名(16) | 图号(14)
            double rx = x0 + lw, rw = TbW - lw;
            double[] cuts = { 14, 30, 44 };
            foreach (var cy in cuts) Line(tr, ps, rx, y0 + cy, rx + rw, y0 + cy, "标题栏", thin);
            void Cell(double yb, double h, string label, string field, double th)
            {
                Text(tr, db, ps, rx + 1.2, y0 + yb + h - 1.2, label, 2.5, AttachmentPoint.TopLeft);
                Field(tr, db, ps, rx + rw / 2 + 4, y0 + yb + h / 2 - 0.6, field, th, AttachmentPoint.MiddleCenter);
            }
            Cell(44, 12, "设计单位", P("Project_Data", "DesignOrg"), 4);
            Cell(30, 14, "项目名称", P("General", "Project_Name"), 4);
            Cell(14, 16, "图    名", D("DWG_Title"), 5);
            Cell(0, 14, "图    号", D("PnID"), 5);

            // 修订栏（标题栏上方）：表头 + 4 行；列 版次12 | 修订说明 88 | 设计16 | 校核16 | 批准16 | 日期32
            double ry0 = y0 + TbH, rH = RevRowH * (RevRows + 1);
            Rect(tr, ps, x0, ry0, x0 + TbW, ry0 + rH, "标题栏", LineWeight.LineWeight050);
            for (int i = 1; i <= RevRows; i++) Line(tr, ps, x0, ry0 + RevRowH * i, x0 + TbW, ry0 + RevRowH * i, "标题栏", thin);
            double[] cw = { 12, 88, 16, 16, 16, 32 };
            double acc = 0;
            for (int i = 0; i < cw.Length - 1; i++) { acc += cw[i]; Line(tr, ps, x0 + acc, ry0, x0 + acc, ry0 + rH, "标题栏", thin); }
            string[] head = { "版次", "修订说明", "设计", "校核", "批准", "日期" };
            acc = 0;
            for (int i = 0; i < cw.Length; i++) { Text(tr, db, ps, x0 + acc + cw[i] / 2, ry0 + RevRowH / 2, head[i], 3.5, AttachmentPoint.MiddleCenter); acc += cw[i]; }
            // 第 1 行（紧贴表头）= 当前版次，用字段；更早版次由 PidBot titleblock 动词写普通文字到上方行
            string[] cur = { D("Revision"), D("RevNote"), D("Author"), D("Checker"), D("Approver"), D("IssueDate") };
            acc = 0;
            for (int i = 0; i < cw.Length; i++)
            {
                Field(tr, db, ps, x0 + acc + cw[i] / 2, ry0 + RevRowH * 1.5, cur[i], 3, AttachmentPoint.MiddleCenter);
                acc += cw[i];
            }
        }

        static IEnumerable<ObjectId> StyleLibWalk(Transaction tr, ObjectId dictId, int depth)
        {
            if (depth > 6 || !(tr.GetObject(dictId, OpenMode.ForRead) is DBDictionary dict)) yield break;
            foreach (DBDictionaryEntry e in dict)
            {
                if (e.Value.ObjectClass.Name == "AcDbDictionary") { foreach (var x in StyleLibWalk(tr, e.Value, depth + 1)) yield return x; }
                else yield return e.Value;
            }
        }

        // ---------------------------------------------------------------- 工具
        internal static void EnsureTextStyle(Transaction tr, Database db)
        {
            var tt = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
            if (tt.Has(TextStyle)) return;
            tt.UpgradeOpen();
            var ts = new TextStyleTableRecord { Name = TextStyle, FileName = "gbenor.shx", BigFontFileName = "gbcbig.shx", XScale = 1.0 };
            tt.Add(ts); tr.AddNewlyCreatedDBObject(ts, true);
        }

        // PIP 标注块的文字样式用 txt.shx 等非国标字体（txt 的大写 O 是矩形，“CO”印成“C□”）：
        // 凡 SHX 且非 gb* 的文字样式一律改为 gbenor.shx + gbcbig.shx，宽度因子 1；TrueType 与形文件不动
        internal static void GbTextStyles(Transaction tr, Database db)
        {
            var tt = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
            var changed = new List<string>();
            foreach (ObjectId id in tt)
            {
                var t = (TextStyleTableRecord)tr.GetObject(id, OpenMode.ForRead);
                if (t.IsShapeFile) continue;
                string f = (t.FileName ?? "").Trim().ToLowerInvariant();
                bool shx = f.Length == 0 || f.EndsWith(".shx") || !f.Contains('.');
                if (!shx || f.StartsWith("gb")) continue;
                t.UpgradeOpen();
                t.FileName = "gbenor.shx"; t.BigFontFileName = "gbcbig.shx"; t.XScale = 1.0;
                changed.Add($"{t.Name}({f})");
            }
            Entry.L(changed.Count == 0 ? "文字样式均已为国标字体" : $"文字样式改为 gbenor+gbcbig：{string.Join("，", changed)}");
        }

        static void Layer(Transaction tr, Database db, string name, short color, LineWeight lw, bool plot)
        {
            var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            LayerTableRecord r;
            if (lt.Has(name)) r = (LayerTableRecord)tr.GetObject(lt[name], OpenMode.ForWrite);
            else { lt.UpgradeOpen(); r = new LayerTableRecord { Name = name }; lt.Add(r); tr.AddNewlyCreatedDBObject(r, true); }
            r.Color = Color.FromColorIndex(ColorMethod.ByAci, color);
            r.LineWeight = lw;
            r.IsPlottable = plot;
        }

        static void Add(Transaction tr, BlockTableRecord b, Entity e) { b.AppendEntity(e); tr.AddNewlyCreatedDBObject(e, true); }

        static void Rect(Transaction tr, BlockTableRecord b, double x0, double y0, double x1, double y1, string layer, LineWeight lw)
        {
            var pl = new Polyline();
            pl.AddVertexAt(0, new Point2d(x0, y0), 0, 0, 0); pl.AddVertexAt(1, new Point2d(x1, y0), 0, 0, 0);
            pl.AddVertexAt(2, new Point2d(x1, y1), 0, 0, 0); pl.AddVertexAt(3, new Point2d(x0, y1), 0, 0, 0);
            pl.Closed = true; pl.Layer = layer; pl.LineWeight = lw;
            Add(tr, b, pl);
        }

        static void Line(Transaction tr, BlockTableRecord b, double x0, double y0, double x1, double y1, string layer, LineWeight lw)
            => Add(tr, b, new Autodesk.AutoCAD.DatabaseServices.Line(new Point3d(x0, y0, 0), new Point3d(x1, y1, 0)) { Layer = layer, LineWeight = lw });

        static MText MT(Transaction tr, Database db, double x, double y, string s, double h, AttachmentPoint ap, double w)
        {
            var tt = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
            var m = new MText { Location = new Point3d(x, y, 0), TextHeight = h, Attachment = ap, TextStyleId = tt[TextStyle], Layer = "标题栏文字", Contents = s };
            if (w > 0) m.Width = w;
            return m;
        }

        static void Text(Transaction tr, Database db, BlockTableRecord b, double x, double y, string s, double h, AttachmentPoint ap)
            => Add(tr, b, MT(tr, db, x, y, s, h, ap, 0));

        static void Field(Transaction tr, Database db, BlockTableRecord b, double x, double y, string code, double h, AttachmentPoint ap, double w = 0)
        {
            var m = MT(tr, db, x, y, "-", h, ap, w);
            Add(tr, b, m);
            var f = new Autodesk.AutoCAD.DatabaseServices.Field(code);
            m.SetField(f);
            tr.AddNewlyCreatedDBObject(f, true);
        }
    }
}
