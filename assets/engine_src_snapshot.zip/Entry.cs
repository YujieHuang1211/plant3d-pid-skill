// PidBot 核心 — AutoCAD Plant 3D 2026 P&ID 自动绘图
// 由 PidBotLoader 的 PB/PBS 命令热加载调用：Entry.Run(verb, arg)，结果写入 _PidBot\logs\<verb>.log
//   会话上下文(PBS)：newproject <json> | openproject <Project.xml> | newdwg <文件名> | styles
//   文档上下文(PB) ：draw <json> | info | props <rowid,...> | pdf <输出pdf>[|window|x1,y1,x2,y2] | clear
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.PlottingServices;
using Autodesk.ProcessPower.DataLinks;
using Autodesk.ProcessPower.DataObjects;
using Autodesk.ProcessPower.P3dProjectParts;
using Autodesk.ProcessPower.PlantInstance;
using Autodesk.ProcessPower.PnIDObjects;
using Autodesk.ProcessPower.PnP3dContentMgd;
using Autodesk.ProcessPower.PnPProjectSetup;
using Autodesk.ProcessPower.ProjectManager;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;
using PmCommands = Autodesk.ProcessPower.ProjectManagerUI.Commands;

namespace PidBot
{
    public static class Entry
    {
        static readonly string LogDir = @"E:\05p_id图绘制中心\_PidBot\logs";
        static StringBuilder _log;
        static string _live;   // 逐行落盘的进度日志 <verb>.live.log：AutoCAD 中途崩溃时可看到最后一步

        internal static void Trace(string s)
        {
            if (_live == null) return;
            try { File.AppendAllText(_live, s + "\n", new UTF8Encoding(false)); } catch { }
        }

        internal static void L(string s)
        {
            _log?.AppendLine(s);
            Trace(s);
            try { AcApp.DocumentManager.MdiActiveDocument?.Editor.WriteMessage("\n[PidBot] " + s); } catch { }
        }

        public static void Run(string verb, string arg)
        {
            verb = verb.ToLowerInvariant();
            _log = new StringBuilder();
            Directory.CreateDirectory(LogDir);
            _live = Path.Combine(LogDir, verb + ".live.log");
            try { File.WriteAllText(_live, "", new UTF8Encoding(false)); } catch { }
            L($"=== {DateTime.Now:yyyy-MM-dd HH:mm:ss} {verb} {arg}");
            try
            {
                // 关闭文档后 WorkingDatabase 可能仍指向已释放的数据库，下一步操作会致命错误（AV 0x0008）；每次先校正
                var act = AcApp.DocumentManager.MdiActiveDocument;
                if (act != null && HostApplicationServices.WorkingDatabase != act.Database) { HostApplicationServices.WorkingDatabase = act.Database; L("已校正 WorkingDatabase → " + act.Name); }
                switch (verb)
                {
                    case "newproject": NewProject(arg); break;
                    case "openproject": OpenProject(arg); break;
                    case "newdwg": NewDwg(arg); break;
                    case "styles": Styles(); break;
                    case "draw": new Drawer(L).Run(arg); break;
                    case "info": Info(); break;
                    case "props": Props(arg); break;
                    case "pdf": Pdf(arg); break;
                    case "clear": ClearModel(); break;
                    case "purge": PurgeEmptyLineGroups(); break;
                    case "reflect": Library.Reflect(arg); break;
                    case "stylesof": Library.StylesOf(arg); break;
                    case "tagformats": Library.TagFormats(arg); break;
                    case "dwginfo": Library.DwgInfo(arg); break;
                    case "schema": Schema.Run(arg); break;
                    case "mkdwt": Template.Make(arg); break;
                    case "settemplate": SetTemplate(arg); break;
                    case "projprops": Library.ProjProps(arg); break;
                    case "qsave":   // 排队执行 QSAVE（Plant 在存盘时把对象数据写入项目库）
                        AcApp.DocumentManager.MdiActiveDocument.Editor.Command("_.QSAVE");   // 同步执行：返回即已存盘
                        L("已存盘 QSAVE: " + AcApp.DocumentManager.MdiActiveDocument.Name); break;
                    case "conn": Verify.Conn(arg); break;
                    case "regen": Regen(); break;
                    case "rmdwg": RemoveDwg(arg); break;
                    case "opendwg":   // 打开（或激活已打开的）项目图纸
                        {
                            var part = PlantApplication.ProjectPart("PnId");
                            string f = Path.IsPathRooted(arg) ? arg : Path.Combine(part.ProjectDwgDirectory, arg);
                            Document hit = null;
                            foreach (Document d in AcApp.DocumentManager) if (string.Equals(d.Name, f, StringComparison.OrdinalIgnoreCase)) hit = d;
                            hit ??= AcApp.DocumentManager.Open(f, false);
                            AcApp.DocumentManager.MdiActiveDocument = hit;
                            L("当前图纸: " + hit.Name);
                        }
                        break;
                    case "blockinfo": Library.BlockInfo(arg); break;
                    case "explode": Library.Explode(arg); break;
                    case "stylecfg": StyleLib.Config(arg); break;
                    case "syncstyles": StyleLib.Sync(arg); break;
                    case "dwgprops": Library.DwgProps(arg); break;
                    default: L("未知动词: " + verb); break;
                }
            }
            catch (System.Exception ex) { L("错误: " + ex); }
            finally
            {
                Directory.CreateDirectory(LogDir);
                File.WriteAllText(Path.Combine(LogDir, verb + ".log"), _log.ToString(), new UTF8Encoding(false));
                _log = null;
            }
        }

        static string AcadDir => Path.GetDirectoryName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);
        static string Vert => Path.Combine(AcadDir, "PLNT3D");
        static string VertCult => Path.Combine(Vert, CultureInfo.CurrentUICulture.Name);

        // ------------------------------------------------------------------ 新建 PIP 公制项目（复刻“新建项目”向导的非复制分支）
        // 参数：JSON {"parentDir":..., "name":..., "description":...}
        static void NewProject(string cfgPath)
        {
            PlantProject tmpl = null;
            try
            {
                using var js = JsonDocument.Parse(File.ReadAllText(cfgPath));
                var c = js.RootElement;
                string name = c.GetProperty("name").GetString();
                string desc = c.TryGetProperty("description", out var d) ? d.GetString() : "";
                string projDir = Path.GetFullPath(Path.Combine(c.GetProperty("parentDir").GetString(), name));
                if (File.Exists(Path.Combine(projDir, "Project.xml"))) throw new InvalidOperationException("目标目录已存在 Project.xml: " + projDir);

                string pidDir = Path.Combine(projDir, "PID DWG");
                string p3dDir = Path.Combine(projDir, "Plant 3D 模型");
                string relDir = Path.Combine(projDir, "相关文件");
                string specDir = Path.Combine(projDir, "等级库工作表");
                string orthoDir = Path.Combine(projDir, "Orthos");
                foreach (var dir in new[] { projDir, pidDir, p3dDir, relDir, specDir, orthoDir }) Directory.CreateDirectory(dir);
                L("项目目录: " + projDir);

                string tmplFile = Path.Combine(Vert, "PIP_Metric_Project.xml");
                tmpl = PlantProject.LoadProject(tmplFile, true, null, null);

                string sym = "";
                if (tmpl.ProjectParts["PnId"] is PnIdProject pnid)
                {
                    sym = Path.Combine(VertCult, PnIdProjectTemplateHelper.GetTemplateFileName(pnid.PnidStandard, PnIdProjectTemplateHelper.ProjectFileType.ProjSymbolStyle));
                    pnid.SymbolAndStyleCacheFile = sym;
                    pnid.SubstitutionPalettesFile = Path.Combine(VertCult, PnIdProjectTemplateHelper.GetTemplateFileName(pnid.PnidStandard, PnIdProjectTemplateHelper.ProjectFileType.SubstitutionPalettes));
                    L($"P&ID 标准={pnid.PnidStandard} 符号库={sym}");
                }
                if (tmpl.ProjectParts["Piping"] is PipingProject tp)
                {
                    tp.SymbolAndStyleCacheFile = sym;
                    tp.DefaultConnectorsConfigFile = Path.Combine(VertCult, "DefaultConnectorsConfig.xml");
                    tp.PipeBendConfigFile = Path.Combine(Vert, "Metric_PipeBendDefaultValues.txt");
                    tp.ToolPaletteDirectory = Vert + "\\UserDataCache\\Support\\ToolPalette";
                }

                var caches = new Dictionary<string, PnPDatabaseLink>(StringComparer.InvariantCultureIgnoreCase);
                var dwgDirs = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase);
                foreach (Project part in tmpl.ProjectParts)
                {
                    string pn = tmpl.ProjectPartName(part);
                    var link = new PnPDatabaseLink { DatabaseEngine = PnPDatabase.SQLiteEngineClass };
                    string db = pn.Equals("PnId", StringComparison.OrdinalIgnoreCase) ? "ProcessPower" : pn;
                    link.Add("Data Source", $"{projDir}\\{db}.dcf");
                    caches[pn] = link;
                    dwgDirs[pn] = pn.Equals("PnId", StringComparison.OrdinalIgnoreCase) ? pidDir
                                : pn.Equals("Ortho", StringComparison.OrdinalIgnoreCase) ? orthoDir
                                : pn.Equals("Misc", StringComparison.OrdinalIgnoreCase) ? relDir : p3dDir;
                }

                var prj = PlantProject.CreateProject(name, desc, projDir, false, dwgDirs, caches, tmpl);
                prj.ProjectPartDirectories.Add("SpecSheets", new FileHelper(projDir, specDir));
                prj.ProjectPartDirectories.Add("Ortho", new FileHelper(projDir, orthoDir));
                prj.ProjectPartDirectories.Add("Related Files", new FileHelper(projDir, relDir));

                var np = prj.ProjectParts["Piping"] as PipingProject;
                if (np != null) np.ProjectUnitsType = ProjectUnitsType.eMetric;
                Util.CreateIsometricDirectories(projDir, VertCult, np);
                Util.DefaultIsoSettings();
                Util.CreateOrthosDirectories(projDir, VertCult, np);
                if (np != null)
                {
                    foreach (string cp in PnP3dContentConfig.GetInstance().getAvailableCPackPaths(string.Empty))
                        Util.CopySpecAndCatalogFiles(cp, specDir);
                    np.SpecSheetsDirectory = specDir;
                    string snap = Path.Combine(projDir, "设备样板");
                    Directory.CreateDirectory(snap);
                    np.EquipmentSnapshotDirectory = snap;
                }
                foreach (var f in new[] { "PIDTo3dClassMapping.xml", "PIDToSpecClassMapping.xml" })
                {
                    string src = Path.Combine(Vert, f);
                    if (File.Exists(src)) File.Copy(src, Path.Combine(projDir, f), true);
                }
                prj.Save();
                np?.CreateSpecItemsFromSpecFolder();
                L("项目已保存: " + prj.FileName);
            }
            finally
            {
                try { tmpl?.Close(); } catch (System.Exception ex) { L("关闭模板出错: " + ex.Message); }
            }
        }

        // 刷新全部 P&ID 线段图形（API 生成的线需刷新才显示间隙与线型）并重生成
        static void Regen()
        {
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            var db = doc.Database;
            int n = 0;
            var ids = new List<ObjectId>();
            using (var tr = db.TransactionManager.StartTransaction())
            {
                var ms = (BlockTableRecord)tr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(db), OpenMode.ForRead);
                foreach (ObjectId id in ms) if (id.ObjectClass.Name.Contains("LineSegment") || tr.GetObject(id, OpenMode.ForRead) is LineSegment) ids.Add(id);
                tr.Commit();
            }
            foreach (var id in ids) { try { LineSegment.RefreshSline(id); n++; } catch (System.Exception ex) { L("刷新失败 " + id.Handle + ": " + ex.Message); } }
            // 动态资产（跨图连接器、仪表圈等）：关闭自动化插入后属性文字不会自动刷新，逐个 Refresh
            int nd = 0;
            using (doc.LockDocument())
            using (var tr = db.TransactionManager.StartTransaction())
            {
                var ms = (BlockTableRecord)tr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(db), OpenMode.ForRead);
                foreach (ObjectId id in ms)
                    if (tr.GetObject(id, OpenMode.ForRead) is DynamicAsset da)
                    {
                        try { da.UpgradeOpen(); da.Refresh(); nd++; } catch (System.Exception ex) { L("动态资产刷新失败 " + id.Handle + ": " + ex.Message); }
                    }
                tr.Commit();
            }
            L($"已刷新动态资产 {nd} 个");
            try { Autodesk.ProcessPower.PnIDObjects.Utils.UpdateLineGaps(SymbolUtilityServices.GetBlockModelSpaceId(db)); } catch (System.Exception ex) { L("UpdateLineGaps: " + ex.Message); }
            doc.Editor.Regen();
            doc.Editor.Command("_.REGENALL");
            L($"已刷新线段 {n} 条，REGEN 并排队 REGENALL");
        }

        // 设置项目 P&ID 默认图纸模板并保存项目
        static void SetTemplate(string dwt)
        {
            var part = PlantApplication.ProjectPart("PnId") ?? throw new InvalidOperationException("没有当前项目");
            L("原模板: " + part.DwtTemplateFile);
            part.DwtTemplateFile = dwt;
            PlantApplication.CurrentProject.Save();
            L("新模板: " + PlantApplication.ProjectPart("PnId").DwtTemplateFile);
        }

        static void OpenProject(string f)
        {
            PmCommands.OpenProjectFileNoPrompt(f);
            var cur = PlantApplication.CurrentProject;
            L("当前项目: " + (cur == null ? "(无)" : cur.Name + " | " + cur.FileName));
        }

        // ------------------------------------------------------------------ 新建 P&ID 图纸并登记到当前项目
        static void NewDwg(string arg)
        {
            var part = PlantApplication.ProjectPart("PnId") ?? throw new InvalidOperationException("没有当前项目");
            string dwg = Path.IsPathRooted(arg) ? arg : Path.Combine(part.ProjectDwgDirectory, arg);
            if (!dwg.EndsWith(".dwg", StringComparison.OrdinalIgnoreCase)) dwg += ".dwg";
            if (File.Exists(dwg)) throw new InvalidOperationException("文件已存在: " + dwg);
            Document doc = AcApp.DocumentManager.Add(part.DwtTemplateFile);
            AcApp.DocumentManager.MdiActiveDocument = doc;
            dynamic comDoc = doc.GetAcadDocument();
            comDoc.SaveAs(dwg);
            bool exists = false, illegal = false;
            string rid = part.AddPnPDrawingFile(dwg, string.Empty, string.Empty, false, ref exists, ref illegal);
            L($"已登记图纸: {dwg} id={rid}");
            using (doc.LockDocument())
            {
                FixGbViewport(doc);
                Util.UpdateTimeStampMdiActiveDocumentDatabase();
            }
            comDoc.Save();
        }

        // GB 模板布局的视口：按图幅重设为覆盖内框、1:1、打开；最后回到模型空间（Plant 对象必须画在模型空间）
        internal static void FixGbViewport(Document doc)
        {
            var db = doc.Database;
            var lm = LayoutManager.Current;
            string target = null; Template.Paper pp = null;
            using (var tr = db.TransactionManager.StartTransaction())
            {
                foreach (DBDictionaryEntry e in (DBDictionary)tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead))
                {
                    var lo = (Layout)tr.GetObject(e.Value, OpenMode.ForRead);
                    if (lo.ModelType || !lo.CanonicalMediaName.Contains("full_bleed")) continue;
                    target = lo.LayoutName;
                    pp = Template.Get(lo.CanonicalMediaName.Contains("A1") ? "A1" : "A3");
                }
                tr.Commit();
            }
            if (target == null) { L("非 GB 模板布局，跳过视口修正"); return; }
            lm.CurrentLayout = target;
            using (var tr = db.TransactionManager.StartTransaction())
            {
                var lo = (Layout)tr.GetObject(lm.GetLayoutId(target), OpenMode.ForRead);
                var ps = (BlockTableRecord)tr.GetObject(lo.BlockTableRecordId, OpenMode.ForRead);
                foreach (ObjectId id in ps)
                {
                    if (!(tr.GetObject(id, OpenMode.ForRead) is Viewport vp) || vp.Layer != "视口") continue;
                    vp.UpgradeOpen();
                    vp.CenterPoint = new Point3d((pp.X0 + pp.X1) / 2, (pp.Y0 + pp.Y1) / 2, 0);
                    vp.Width = pp.X1 - pp.X0; vp.Height = pp.Y1 - pp.Y0;
                    vp.ViewCenter = new Point2d((pp.X0 + pp.X1) / 2, (pp.Y0 + pp.Y1) / 2);
                    vp.ViewHeight = pp.Y1 - pp.Y0;
                    vp.On = true; vp.Locked = true;
                    L($"视口已修正: {pp.Name} 中心({vp.CenterPoint.X},{vp.CenterPoint.Y}) {vp.Width}×{vp.Height} 1:1");
                }
                tr.Commit();
            }
            lm.CurrentLayout = "Model";
        }

        // 从项目移除图纸并删除文件（仅用于临时/测试图）
        static void RemoveDwg(string name)
        {
            var part = PlantApplication.ProjectPart("PnId") ?? throw new InvalidOperationException("没有当前项目");
            string full = Path.Combine(part.ProjectDwgDirectory, name);
            var pd = part.GetPnPDrawingFiles().Cast<PnPProjectDrawing>().FirstOrDefault(x =>
                         string.Equals(Path.GetFileName(x.ResolvedFilePath ?? ""), name, StringComparison.OrdinalIgnoreCase))
                     ?? throw new InvalidOperationException("项目中无此图纸: " + name + "；现有: " +
                         string.Join(", ", part.GetPnPDrawingFiles().Cast<PnPProjectDrawing>().Select(x => x.ResolvedFilePath)));
            foreach (Document d in AcApp.DocumentManager)
                if (Path.GetFileName(d.Name).Equals(name, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("图纸仍打开，请先用 acadctl.ps1 -CloseDoc 关闭（命令内关闭文档会致 AutoCAD 致命错误）");
            bool ok = part.RemovePnPDrawingFile(pd);
            if (!ok) throw new InvalidOperationException("项目拒绝移除图纸，文件未删除: " + name);
            foreach (var ext in new[] { ".dwg", ".bak", ".dwl", ".dwl2" })
            {
                string f = Path.ChangeExtension(full, ext);
                if (File.Exists(f)) File.Delete(f);
            }
            L($"已移除图纸 {name}: {ok}");
        }

        // ------------------------------------------------------------------ 列出项目符号样式键名
        static void Styles()
        {
            string sym = PlantApplication.ProjectPart("PnId").SymbolAndStyleCacheFile;
            L("符号库: " + sym);
            using var db = new Database(false, true);
            db.ReadDwgFile(sym, FileOpenMode.OpenForReadAndAllShare, true, null);
            using var tr = db.TransactionManager.StartTransaction();
            Walk(tr, db.NamedObjectsDictionaryId, "", 0);
            tr.Commit();
        }

        static void Walk(Transaction tr, ObjectId dictId, string path, int depth)
        {
            if (depth > 4 || !(tr.GetObject(dictId, OpenMode.ForRead) is DBDictionary dict)) return;
            foreach (DBDictionaryEntry e in dict)
            {
                string cls = e.Value.ObjectClass.Name;
                if (cls == "AcDbDictionary") Walk(tr, e.Value, path + "/" + e.Key, depth + 1);
                else if (cls.Contains("Style")) L($"{cls}\t{path}\t{e.Key}");
            }
        }

        // ------------------------------------------------------------------ 当前图纸对象清单
        static void Info()
        {
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            var db = doc.Database;
            L($"图纸: {doc.Name}  EXTMIN={db.Extmin} EXTMAX={db.Extmax}");
            DataLinksManager dlm = PlantApplication.ProjectPart("PnId")?.DataLinksManager;
            using var tr = db.TransactionManager.StartTransaction();
            var ms = (BlockTableRecord)tr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(db), OpenMode.ForRead);
            foreach (ObjectId id in ms)
            {
                if (!(tr.GetObject(id, OpenMode.ForRead) is Entity ent)) continue;
                string ext = "";
                try { var e = ent.GeometricExtents; ext = $"[{e.MinPoint.X:F1},{e.MinPoint.Y:F1}]-[{e.MaxPoint.X:F1},{e.MaxPoint.Y:F1}]"; } catch { }
                string extra = "";
                if (ent is Asset a)
                {
                    string st = ""; try { st = PnIDStyleUtils.GetStyleNameFromId(a.StyleId); } catch { }
                    extra = $" style={st} pos=({a.Position.X:F1},{a.Position.Y:F1}) ang={a.XAxisAngle * 180 / Math.PI:F0} scale={a.ScaleFactors.X:F2}";
                    try { extra += " att=" + string.Join(";", a.AttachmentPoints.Cast<Point3d>().Select(p => $"({p.X:F1},{p.Y:F1})")); } catch { }
                }
                if (ent is BlockReference br) extra += " block=" + br.Name;
                if (ent is LineSegment ls)
                {
                    string st = "";
                    extra += $" vis={ls.Visible} color={ls.Color} lt={ls.Linetype} lw={ls.LineWeight} style={st}";
                }
                if (ent is MText mt) extra += " mtext=" + mt.Contents.Replace("\\P", " ").Substring(0, Math.Min(40, mt.Contents.Length));
                if (dlm != null)
                {
                    try
                    {
                        int rid = dlm.FindAcPpRowId(id);
                        if (rid > 0)
                        {
                            var props = dlm.GetAllProperties(rid, true);
                            extra += $" row={rid} class={dlm.GetObjectClassname(rid)} tag={props.FirstOrDefault(p => p.Key == "Tag").Value}";
                        }
                    }
                    catch { }
                }
                L($"{ent.GetType().Name} h={ent.Handle} layer={ent.Layer} {ext}{extra}");
            }
            tr.Commit();
        }

        static void Props(string arg)
        {
            var dlm = PlantApplication.ProjectPart("PnId").DataLinksManager;
            foreach (var s in arg.Split(','))
            {
                int rid = int.Parse(s.Trim());
                L($"--- row {rid} class={dlm.GetObjectClassname(rid)}");
                foreach (var kv in dlm.GetAllProperties(rid, true)) L($"   {kv.Key} = {kv.Value}");
            }
        }

        // ------------------------------------------------------------------ 清空模型空间（保留“未打印”图层上的图框网格）
        internal static void ClearModel()
        {
            var db = AcApp.DocumentManager.MdiActiveDocument.Database;
            int n = 0;
            using var tr = db.TransactionManager.StartTransaction();
            var ms = (BlockTableRecord)tr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(db), OpenMode.ForRead);
            foreach (var id in ms.Cast<ObjectId>().ToList())
            {
                if (id.IsErased || !(tr.GetObject(id, OpenMode.ForRead) is Entity e) || e.Layer == "未打印") continue;
                try { e.UpgradeOpen(); e.Erase(); n++; } catch (System.Exception ex) { L($"删除失败 {e.GetType().Name}: {ex.Message}"); }
            }
            tr.Commit();
            L($"已删除 {n} 个对象（不做全项目空线组清理：可能删到其他图纸的线组）");
        }

        // 删除没有任何线段的线组（清图后残留，会导致新线号出现“?”重复标记）
        internal static void PurgeEmptyLineGroups()
        {
            var dlm = PlantApplication.ProjectPart("PnId").DataLinksManager;
            var lgm = new LineGroupManager(dlm);
            var pdb = dlm.GetPnPDatabase();
            int n = 0;
            foreach (var table in new[] { "PipeLineGroup", "SignalLineGroup" })
            {
                PnPTable t = null;
                try { t = pdb.Tables[table]; } catch { }
                if (t == null) continue;
                foreach (PnPRow row in t.Select())
                {
                    int rid = Convert.ToInt32(row["PnPID"]);
                    int cnt = -1;
                    try { cnt = lgm.Count(rid); } catch { }
                    if (cnt == 0)
                    {
                        try { dlm.RemoveItem(rid); n++; } catch (System.Exception ex) { L($"删除空线组 {rid} 失败: {ex.Message}"); }
                    }
                }
            }
            L($"已删除空线组 {n} 个");
        }

        // ------------------------------------------------------------------ 出 PDF（DWG To PDF.pc3，前台打印）
        // 参数：pdf路径                      → 打印第一个图纸布局（含图框），1:1
        //       pdf路径|window|x1,y1,x2,y2  → 打印模型空间窗口，A1 布满
        static void Pdf(string arg)
        {
            var parts = arg.Split('|');
            string pdf = parts[0];
            bool window = parts.Length >= 3 && parts[1] == "window";
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            var db = doc.Database;
            var lm = LayoutManager.Current;
            string prevLayout = lm.CurrentLayout;
            if (!window)
            {
                string first = null; int best = int.MaxValue;
                using (var t0 = db.TransactionManager.StartTransaction())
                {
                    foreach (DBDictionaryEntry e in (DBDictionary)t0.GetObject(db.LayoutDictionaryId, OpenMode.ForRead))
                    {
                        var lo = (Layout)t0.GetObject(e.Value, OpenMode.ForRead);
                        if (!lo.ModelType && lo.TabOrder < best) { best = lo.TabOrder; first = lo.LayoutName; }
                    }
                    t0.Commit();
                }
                lm.CurrentLayout = first;
            }
            else lm.CurrentLayout = "Model";
            object bg = AcApp.GetSystemVariable("BACKGROUNDPLOT");
            AcApp.SetSystemVariable("BACKGROUNDPLOT", (short)0);
            try
            {
                using var tr = db.TransactionManager.StartTransaction();
                ObjectId layoutId = ObjectId.Null;
                var dict = (DBDictionary)tr.GetObject(db.LayoutDictionaryId, OpenMode.ForRead);
                if (window) layoutId = dict.GetAt("Model");
                else
                {
                    int best = int.MaxValue;
                    foreach (DBDictionaryEntry e in dict)
                    {
                        var lo = (Layout)tr.GetObject(e.Value, OpenMode.ForRead);
                        if (!lo.ModelType && lo.TabOrder < best) { best = lo.TabOrder; layoutId = e.Value; }
                    }
                }
                var layout = (Layout)tr.GetObject(layoutId, OpenMode.ForRead);
                var ps = new PlotSettings(layout.ModelType);
                ps.CopyFrom(layout);
                var psv = PlotSettingsValidator.Current;
                string keepMedia = layout.CanonicalMediaName;
                L($"布局原页面设置: 设备={layout.PlotConfigurationName} 图纸={keepMedia} 旋转={layout.PlotRotation} 类型={layout.PlotType}");
                psv.SetPlotConfigurationName(ps, "DWG To PDF.pc3", null);
                psv.RefreshLists(ps);
                var media = psv.GetCanonicalMediaNameList(ps).Cast<string>().ToList();
                string m;
                if (window)
                {
                    m = media.FirstOrDefault(x => x.Contains("full_bleed_A1_(841")) ?? media.FirstOrDefault(x => x.Contains("A1")) ?? media[0];
                    psv.SetCanonicalMediaName(ps, m);
                    psv.SetPlotPaperUnits(ps, PlotPaperUnit.Millimeters);
                    var c = parts[2].Split(',').Select(v => double.Parse(v, CultureInfo.InvariantCulture)).ToArray();
                    psv.SetPlotWindowArea(ps, new Extents2d(c[0], c[1], c[2], c[3]));
                    psv.SetPlotType(ps, Autodesk.AutoCAD.DatabaseServices.PlotType.Window);
                    psv.SetUseStandardScale(ps, true);
                    psv.SetStdScaleType(ps, StdScaleType.ScaleToFit);
                    psv.SetPlotRotation(ps, PlotRotation.Degrees000);
                }
                else if (keepMedia.Contains("full_bleed"))
                {
                    // GB 模板布局：页面设置已按图幅 1:1 配好，原样使用
                    m = keepMedia;
                    psv.SetCanonicalMediaName(ps, m);
                    psv.SetPlotType(ps, Autodesk.AutoCAD.DatabaseServices.PlotType.Layout);
                    psv.SetUseStandardScale(ps, true);
                    psv.SetStdScaleType(ps, StdScaleType.StdScale1To1);
                    psv.SetPlotRotation(ps, PlotRotation.Degrees000);
                }
                else
                {
                    m = media.FirstOrDefault(x => x.Contains("full_bleed_A1_(841")) ?? media.FirstOrDefault(x => x.Contains("A1_(841")) ?? keepMedia;
                    psv.SetCanonicalMediaName(ps, m);
                    psv.SetPlotType(ps, Autodesk.AutoCAD.DatabaseServices.PlotType.Extents);
                    psv.SetUseStandardScale(ps, true);
                    psv.SetStdScaleType(ps, StdScaleType.ScaleToFit);
                    psv.SetPlotRotation(ps, PlotRotation.Degrees000);
                    psv.SetPlotCentered(ps, true);
                }
                if (window) psv.SetPlotCentered(ps, true);
                try { psv.SetCurrentStyleSheet(ps, "monochrome.ctb"); } catch { }
                var pi = new PlotInfo { Layout = layoutId, OverrideSettings = ps };
                var piv = new PlotInfoValidator { MediaMatchingPolicy = MatchingPolicy.MatchEnabled };
                piv.Validate(pi);
                using (var pe = PlotFactory.CreatePublishEngine())
                {
                    pe.BeginPlot(null, null);
                    pe.BeginDocument(pi, doc.Name, null, 1, true, pdf);
                    pe.BeginPage(new PlotPageInfo(), pi, true, null);
                    pe.BeginGenerateGraphics(null);
                    pe.EndGenerateGraphics(null);
                    pe.EndPage(null);
                    pe.EndDocument(null);
                    pe.EndPlot(null);
                }
                tr.Commit();
                L($"已输出 PDF: {pdf}  布局={layout.LayoutName} 图纸={m}");
            }
            finally
            {
                AcApp.SetSystemVariable("BACKGROUNDPLOT", bg);
                try { lm.CurrentLayout = prevLayout; } catch { }
            }
        }
    }
}
