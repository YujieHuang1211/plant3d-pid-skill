﻿# 一张 P&ID 的完整生成流程（Windows PowerShell 5），每张图在全新的 AutoCAD 会话中重建：
#   退出 AutoCAD → 重启并打开项目 → 移除旧图 → 新建 → 图纸属性 → 同步样式 → 绘制 → 标注 → 刷新 → 存盘 → PDF
#   build_sheet.ps1 -Dwg "P&ID-101_xxx.dwg" -Props <dwgprops.json> -Spec <spec.json> -Pdf <out.pdf> [-Project <Project.xml>] [-NoAnno]
#   任一步出现对话框或“错误:”即停止本批，日志保留在 _PidBot\logs（*.live.log 为逐行进度）
param([string]$Dwg, [string]$Props, [string]$Spec, [string]$Pdf,
      [string]$Project = 'E:\05p_id图绘制中心\青木子纽扣电池测试台\Project.xml', [switch]$NoAnno)
$ErrorActionPreference = 'Stop'
$s = 'E:\05p_id图绘制中心\_PidBot\scripts\send.ps1'
$c = 'E:\05p_id图绘制中心\_PidBot\scripts\acadctl.ps1'
$cfg = 'E:\05p_id图绘制中心\_PidBot\specs\qmz_stylecfg.json'
function Step($verb, $arg, $t = 180) {
  $r = & powershell -NoProfile -File $s -Verb $verb -Arg $arg -TimeoutSec $t
  $d = & powershell -NoProfile -File $c -Dialogs
  if ($d) { "!! 对话框: $d"; throw "AutoCAD 出现对话框，停止本批" }
  $r | Select-String '错误|失败|超时|完成|已' | ForEach-Object { "  [$verb] " + $_.Line }
  if ($r -match '错误:') { throw "$verb 报错，停止本批" }
  if ($r -match '超时') { throw "$verb 超时（命令可能被吞），停止本批" }
}
& powershell -NoProfile -File $c -Quit
$rs = & powershell -NoProfile -File $c -Restart -Project $Project
if ($LASTEXITCODE -ne 0 -or -not ($rs -match '当前项目')) { $rs; throw '重启 AutoCAD 或打开项目失败，停止本批' }
$rs | Select-String '当前项目|就绪|图形修复'
$f = Join-Path (Join-Path (Split-Path $Project) 'PID DWG') $Dwg
if (Test-Path $f) { Step 'rmdwg' $Dwg 60 }
Step 'newdwg' $Dwg 120
Step 'dwgprops' $Props 60
Step 'syncstyles' $cfg 300
Step 'draw' $Spec 600
$anno = [IO.Path]::ChangeExtension($Spec, '.anno.lsp')
if ((Test-Path $anno) -and -not $NoAnno) { & powershell -NoProfile -File $s -Anno $anno }
Step 'regen' 'x' 120
Step 'qsave' 'x' 60
Start-Sleep 4
Step 'pdf' $Pdf 180
