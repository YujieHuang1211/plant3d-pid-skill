// 项目符号库配置（projSymbolStyle.dwg）：统一尺寸/线宽/标注字高，导入 ISA 补充样式，建立自定义智能符号
//   stylecfg <json>
//   {
//     "set":    [{"name":"Ball Valve Style","scale":8}, {"name":"Primary Style","lw":50},
//                {"name":"Equipment Tag","annScale":17.5}, {"name":"Field Mounted Discrete Instrument Style","scale":20,"attH":0.125}],
//     "import": [{"lib":"<ISA_projSymbolStyle.dwg>","name":"Diaphragm Spring Actuator","scale":32}],
//     "custom": [{"name":"QMZ MFC Style","class":"MassFlowController","desc":"..","join":"InLine","scale":1,"layer":"仪器",
//                 "geom":[{"pl":[[x,y],...],"c":true},{"circle":[x,y,r]},{"arc":[x,y,r,a0,a1]},{"t":"MFC","at":[0,0],"h":2.5}]}]
//   }
//   syncstyles   把项目符号库里的全部 P&ID 样式复制（覆盖）到当前图纸，保证图纸与项目库一致
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.ProcessPower.PlantInstance;
using Autodesk.ProcessPower.PnIDObjects;
using Autodesk.ProcessPower.Styles;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;

namespace PidBot
{
    public static class StyleLib
    {
        static void L(string s) => Entry.L(s);

        // 同名样式可能同时有 AssetStyle 与 AnnotationStyle（如现场仪表圈），按名称返回全部
        static Dictionary<string, List<ObjectId>> StylesIn(Transaction tr, Database db)
        {
            var d = new Dictionary<string, List<ObjectId>>(StringComparer.OrdinalIgnoreCase);
            foreach (var id in Walk(tr, db.NamedObjectsDictionaryId, 0))
                if (tr.GetObject(id, OpenMode.ForRead) is Style s)
                {
                    if (!d.TryGetValue(s.Name, out var l)) d[s.Name] = l = new List<ObjectId>();
                    l.Add(id);
                }
            return d;
        }

        static IEnumerable<ObjectId> Walk(Transaction tr, ObjectId dictId, int depth)
        {
            if (depth > 6 || !(tr.GetObject(dictId, OpenMode.ForRead) is DBDictionary dict)) yield break;
            foreach (DBDictionaryEntry e in dict)
            {
                if (e.Value.ObjectClass.Name == "AcDbDictionary") { foreach (var x in Walk(tr, e.Value, depth + 1)) yield return x; }
                else yield return e.Value;
            }
        }

        public static void Config(string arg)
        {
            string sym = PlantApplication.ProjectPart("PnId").SymbolAndStyleCacheFile;
            using var js = JsonDocument.Parse(File.ReadAllText(arg), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
            var root = js.RootElement;
            using var db = new Database(false, true);
            db.ReadDwgFile(sym, FileOpenMode.OpenForReadAndAllShare, true, null);
            db.CloseInput(true);
            // 新建样式/块期间把工作数据库指向符号库，避免 AddStyle 等按当前图纸解析而产生跨库引用（保存时报“保存过程中发生错误”）
            var prevWdb = HostApplicationServices.WorkingDatabase;
            HostApplicationServices.WorkingDatabase = db;
            try
            {

            // 1) 导入 ISA（或其他库）样式
            if (root.TryGetProperty("import", out var imps))
                foreach (var im in imps.EnumerateArray())
                {
                    string lib = im.GetProperty("lib").GetString(), name = im.GetProperty("name").GetString();
                    using var src = new Database(false, true);
                    src.ReadDwgFile(lib, FileOpenMode.OpenForReadAndAllShare, true, null);
                    var nid = ProjectSymbolStyleUtils.CopyStyle(name, src, db);
                    L($"导入 {name} ← {Path.GetFileName(lib)}: {(nid.IsValid ? "成功" : "失败")}");
                }

            // 2) 自定义智能符号
            if (root.TryGetProperty("custom", out var cus))
                foreach (var c in cus.EnumerateArray()) AddCustom(db, c);

            // 3) 统一尺寸、线宽、标注字高；标注块所用文字样式统一为国标字体
            if (root.TryGetProperty("set", out var sets)) ApplySets(db, sets);
            using (var trg = db.TransactionManager.StartTransaction()) { Template.GbTextStyles(trg, db); trg.Commit(); }

            string tmp = Path.Combine(Path.GetTempPath(), "pidbot_sym_" + Guid.NewGuid().ToString("N") + ".dwg");
            int before;
            using (var tr = db.TransactionManager.StartTransaction()) { before = StylesIn(tr, db).Values.Sum(v => v.Count); tr.Commit(); }
            db.SaveAs(tmp, DwgVersion.Current);
            // 重新读取临时文件核对样式数，通过后才替换正式符号库；不通过则保留两份文件并报错
            int after;
            using (var chk = new Database(false, true))
            {
                chk.ReadDwgFile(tmp, FileOpenMode.OpenForReadAndAllShare, true, null);
                using var tr2 = chk.TransactionManager.StartTransaction();
                after = StylesIn(tr2, chk).Values.Sum(v => v.Count);
                tr2.Commit();
            }
            if (after != before) throw new InvalidOperationException($"符号库保存核对不符：保存前 {before} 个样式，重读 {after} 个；临时文件保留 {tmp}");
            File.Copy(tmp, sym, true);
            File.Delete(tmp);
            L($"已保存项目符号库 {sym}（重读核对样式 {after} 个）");
            }
            finally
            {
                var act = AcApp.DocumentManager.MdiActiveDocument?.Database;
                HostApplicationServices.WorkingDatabase = act ?? prevWdb;   // 在侧库 Dispose 之前恢复
            }
        }

        internal static void ApplySets(Database db, JsonElement sets)
        {
                using (var tr = db.TransactionManager.StartTransaction())
                {
                    var all = StylesIn(tr, db);
                    foreach (var s in sets.EnumerateArray())
                    {
                        string name = s.GetProperty("name").GetString();
                        if (!all.TryGetValue(name, out var sids)) { L($"未找到样式 {name}"); continue; }
                        foreach (var sid in sids) {
                        var st = (Style)tr.GetObject(sid, OpenMode.ForWrite);
                        var msg = new List<string>();
                        if (s.TryGetProperty("scale", out var sc) && st is AssetStyle a) { a.ScaleFactor = sc.GetDouble(); msg.Add("scale=" + a.ScaleFactor); }
                        if (s.TryGetProperty("annScale", out var an) && st is AnnotationStyle ans) { ans.ScaleFactor = an.GetDouble(); msg.Add("annScale=" + ans.ScaleFactor); }
                        if (s.TryGetProperty("lw", out var lw)) { st.LineWeight = (LineWeight)lw.GetInt32(); msg.Add("lw=" + st.LineWeight); }
                        if (s.TryGetProperty("attH", out var ah) && st.BlockTableRecord.IsValid)
                        {
                            var btr = (BlockTableRecord)tr.GetObject(st.BlockTableRecord, OpenMode.ForRead);
                            int n = 0;
                            foreach (ObjectId eid in btr)
                                if (tr.GetObject(eid, OpenMode.ForRead) is AttributeDefinition ad) { ad.UpgradeOpen(); ad.Height = ah.GetDouble(); n++; }
                            msg.Add($"attH={ah.GetDouble()}×{n}");
                        }
                        if (s.TryGetProperty("attHide", out var hide) && st.BlockTableRecord.IsValid)
                        {
                            var hs = hide.EnumerateArray().Select(v => v.GetString()).ToHashSet();
                            var btr2 = (BlockTableRecord)tr.GetObject(st.BlockTableRecord, OpenMode.ForRead);
                            int nh = 0;
                            foreach (ObjectId eid in btr2)
                                if (tr.GetObject(eid, OpenMode.ForRead) is AttributeDefinition ad2 && hs.Contains(ad2.Tag)) { ad2.UpgradeOpen(); ad2.Invisible = true; nh++; }
                            msg.Add($"隐藏属性×{nh}");
                        }
                        L($"设置 {name} [{st.GetType().Name}]: {string.Join(", ", msg)}");
                        }
                    }
                    tr.Commit();
                }
        }

        static void AddCustom(Database db, JsonElement c)
        {
            string name = c.GetProperty("name").GetString();
            string bname = "QMZ_" + System.Text.RegularExpressions.Regex.Replace(name, @"[^A-Za-z0-9_]", "_");
            ObjectId btrId;
            using (var tr = db.TransactionManager.StartTransaction())
            {
                if (StylesIn(tr, db).ContainsKey(name)) { L($"自定义样式已存在 {name}（如需重建先改名）"); tr.Commit(); return; }
                Template.EnsureTextStyle(tr, db);
                var tt = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
                var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForWrite);
                if (bt.Has(bname)) { var old = (BlockTableRecord)tr.GetObject(bt[bname], OpenMode.ForWrite); foreach (ObjectId e in old) ((Entity)tr.GetObject(e, OpenMode.ForWrite)).Erase(); btrId = old.ObjectId; }
                else { var b = new BlockTableRecord { Name = bname, Origin = Point3d.Origin }; btrId = bt.Add(b); tr.AddNewlyCreatedDBObject(b, true); }
                var btr = (BlockTableRecord)tr.GetObject(btrId, OpenMode.ForWrite);
                foreach (var g in c.GetProperty("geom").EnumerateArray())
                {
                    Entity e = null;
                    if (g.TryGetProperty("pl", out var pl))
                    {
                        var p = new Polyline(); int i = 0;
                        foreach (var v in pl.EnumerateArray()) p.AddVertexAt(i++, new Point2d(v[0].GetDouble(), v[1].GetDouble()), 0, 0, 0);
                        p.Closed = g.TryGetProperty("c", out var cl) && cl.GetBoolean();
                        e = p;
                    }
                    else if (g.TryGetProperty("circle", out var ci))
                        e = new Circle(new Point3d(ci[0].GetDouble(), ci[1].GetDouble(), 0), Vector3d.ZAxis, ci[2].GetDouble());
                    else if (g.TryGetProperty("arc", out var ar))
                        e = new Arc(new Point3d(ar[0].GetDouble(), ar[1].GetDouble(), 0), ar[2].GetDouble(), ar[3].GetDouble() * Math.PI / 180, ar[4].GetDouble() * Math.PI / 180);
                    else if (g.TryGetProperty("t", out var t))
                        e = new MText
                        {
                            Contents = t.GetString(), TextHeight = g.TryGetProperty("h", out var h) ? h.GetDouble() : 2.5,
                            Location = new Point3d(g.GetProperty("at")[0].GetDouble(), g.GetProperty("at")[1].GetDouble(), 0),
                            Attachment = AttachmentPoint.MiddleCenter, TextStyleId = tt[Template.TextStyle],
                        };
                    if (e == null) continue;
                    // 先加入块（属于符号库数据库），再按名称设图层/线型，否则会按当前图纸解析 → eWrongDatabase
                    btr.AppendEntity(e); tr.AddNewlyCreatedDBObject(e, true);
                    e.Layer = "0"; e.ColorIndex = 0; e.Linetype = "ByBlock"; e.LineWeight = LineWeight.ByBlock;
                    if (g.TryGetProperty("lt", out var lt))
                    {
                        var ltt = (LinetypeTable)tr.GetObject(db.LinetypeTableId, OpenMode.ForRead);
                        if (!ltt.Has(lt.GetString())) db.LoadLineTypeFile(lt.GetString(), "acadiso.lin");
                        e.LinetypeId = ltt[lt.GetString()];
                    }
                    if (g.TryGetProperty("lw", out var elw)) e.LineWeight = (LineWeight)elw.GetInt32();
                }
                tr.Commit();
            }
            using var st = new AssetStyle();
            st.BlockTableRecord = btrId;
            st.ClassName = c.GetProperty("class").GetString();
            st.Description = c.TryGetProperty("desc", out var d) ? d.GetString() : name;
            st.ScaleFactor = c.TryGetProperty("scale", out var s) ? s.GetDouble() : 1.0;
            if (c.TryGetProperty("join", out var j)) st.JoinType = (JoinType)Enum.Parse(typeof(JoinType), j.GetString());
            using (var tr = db.TransactionManager.StartTransaction())
            {
                if (c.TryGetProperty("layer", out var ly))
                {
                    var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
                    if (lt.Has(ly.GetString())) st.LayerId = lt[ly.GetString()];
                }
                tr.Commit();
            }
            PnIDStyleUtils.AddStyle(st, name, db);
            L($"自定义样式 {name}: class={st.ClassName} join={st.JoinType} scale={st.ScaleFactor}");
        }

        public static void Sync(string arg)
        {
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            string sym = PlantApplication.ProjectPart("PnId").SymbolAndStyleCacheFile;
            using var src = new Database(false, true);
            src.ReadDwgFile(sym, FileOpenMode.OpenForReadAndAllShare, true, null);
            List<(string name, bool ann)> names;
            using (var tr = src.TransactionManager.StartTransaction())
            {
                names = StylesIn(tr, src).SelectMany(kv => kv.Value.Select(id => (kv.Key, tr.GetObject(id, OpenMode.ForRead) is AnnotationStyle))).Distinct().ToList();
                tr.Commit();
            }
            string cfg = !string.IsNullOrWhiteSpace(arg) && arg.EndsWith(".json", StringComparison.OrdinalIgnoreCase) ? arg : null;
            var only = string.IsNullOrWhiteSpace(arg) || cfg != null ? null : arg.Split(',').Select(x => x.Trim()).ToHashSet(StringComparer.OrdinalIgnoreCase);
            int ok = 0, bad = 0;
            using (doc.LockDocument())
                foreach (var (name, ann) in names)
                {
                    if (only != null && !only.Contains(name)) continue;
                    if (ann) continue;   // 标注样式 CopyStyle 不支持覆盖（eKeyNotFound），改为下方按配置直接设置
                    try { if (ProjectSymbolStyleUtils.CopyStyle(name, src, doc.Database).IsValid) ok++; else bad++; }
                    catch (System.Exception ex) { bad++; L($"同步失败 {name}: {ex.Message}"); }
                }
            L($"样式同步完成：成功 {ok}，失败 {bad}");
            if (cfg != null)
            {
                using var js = JsonDocument.Parse(File.ReadAllText(cfg), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
                if (js.RootElement.TryGetProperty("set", out var sets))
                    using (doc.LockDocument()) ApplySets(doc.Database, sets);
            }
        }
    }
}
