// 按 JSON 描述在当前 P&ID 图纸中生成 Plant 对象与普通 CAD 注释
//
// JSON 结构：
// {
//   "offset": [x, y],                       // 可选：整体平移
//   "layers": [{"name":"..","color":8,"ltype":"DASHED","lw":50}],   // lw：图层线宽，单位 0.01 mm（50 = 0.50 mm），省略则不改
//   "items": [
//     {"k":"asset", "id":"F-101", "style":"锅炉样式", "at":[x,y], "rot":0, "scale":1, "props":{"Type":"F","Number":"101"}},
//     {"k":"cv",    "id":"FV-101", "body":"控制阀样式", "act":"隔膜样式", "at":[x,y], "rot":0, "props":{}},
//     {"k":"nozzle","on":"F-101", "style":"假定管嘴样式", "at":[x,y], "rot":0},
//     {"k":"line",  "id":"L1", "style":"主样式", "pts":[[x,y],...], "props":{}, "group":{"LineNumber":"001"}},
//     {"k":"text",  "at":[x,y], "text":"..", "h":2.5, "just":"ML", "layer":"..", "color":7, "rot":0, "w":0},
//     {"k":"poly",  "pts":[[x,y],...], "closed":true, "layer":"..", "ltype":"DASHED", "color":8, "lw":0},
//     {"k":"rect",  "at":[x1,y1], "to":[x2,y2], "layer":"..", "ltype":"..", "color":..}
//   ]
// }
// 旋转角单位：度。坐标单位：图纸单位（mm）。
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text.Json;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.ProcessPower.DataLinks;
using Autodesk.ProcessPower.PlantInstance;
using Autodesk.ProcessPower.PnIDObjects;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Core.Application;

namespace PidBot
{
    public class Drawer
    {
        readonly Action<string> L;
        Document doc;
        Database db;
        DataLinksManager dlm;
        Database symDb;
        Vector3d off = new Vector3d(0, 0, 0);
        readonly Dictionary<string, int> rows = new Dictionary<string, int>();
        int ok, fail;

        public Drawer(Action<string> log) { L = log; }

        public void Run(string jsonPath)
        {
            doc = AcApp.DocumentManager.MdiActiveDocument;
            db = doc.Database;
            if (LayoutManager.Current.CurrentLayout != "Model") { LayoutManager.Current.CurrentLayout = "Model"; L("已切换到模型空间"); }
            try { AcApp.SetSystemVariable("WIPEOUTFRAME", (short)0); } catch { }   // 仪表圈内遮罩框不显示、不打印
            dlm = PlantApplication.ProjectPart("PnId").DataLinksManager;
            using var js = JsonDocument.Parse(File.ReadAllText(jsonPath), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
            var root = js.RootElement;
            if (root.TryGetProperty("offset", out var o)) off = new Vector3d(o[0].GetDouble(), o[1].GetDouble(), 0);
            EnsureTextStyle();
            if (root.TryGetProperty("clear", out var cl) && cl.GetBoolean()) Entry.ClearModel();
            LoadRegistry(jsonPath);
            if (root.TryGetProperty("layers", out var lays))
                foreach (var ly in lays.EnumerateArray())
                    EnsureLayer(ly.GetProperty("name").GetString(), Int(ly, "color", 7), Str(ly, "ltype", null), Int(ly, "lw", 0));
            try
            {
                foreach (var it in root.GetProperty("items").EnumerateArray())
                {
                    string k = it.GetProperty("k").GetString();
                    string id = Str(it, "id", "");
                    Entry.Trace($"→ {k} {id}");
                    try
                    {
                        switch (k)
                        {
                            case "style": AddStyleDef(it); break;
                            case "asset": AddAsset(it, id); break;
                            case "cv": AddCv(it, id); break;
                            case "nozzle": AddNozzle(it, id); break;
                            case "line": AddLine(it, id); break;
                            case "text": AddText(it); break;
                            case "poly": AddPoly(it); break;
                            case "rect": AddRect(it); break;
                            case "sym": AddSym(it); break;
                            case "table": AddTable(it); break;
                            case "connect": Connect(it); break;
                            case "tee": Tee(it); break;
                            case "opc": Opc(it); break;
                            default: throw new ArgumentException("未知类型 " + k);
                        }
                        ok++;
                    }
                    catch (System.Exception ex)
                    {
                        fail++;
                        L($"失败 {k} {id}: {ex.GetType().Name}: {ex.Message}");
                        string em = ex.Message ?? "";
                        if (em.Contains("eWasOpenFor") || em.Contains("eHadMultipleReaders") || em.Contains("eNotOpenFor") || em.Contains("eWrongDatabase") || em.Contains("eWasErased"))
                        {
                            L("错误: Plant 对象状态异常，立即终止本次绘图（不再继续后续 Plant 操作）");
                            break;
                        }
                    }
                }
            }
            finally
            {
                symDb?.Dispose();
            }
            SaveRegistry(jsonPath, ownIds);
            WriteAnnoScript(Path.ChangeExtension(jsonPath, ".anno.lsp"));
            L($"完成：成功 {ok}，失败 {fail}");
        }

        // ---------------------------------------------------------------- 标注（PIDANNOTATE 须在命令外执行：生成 LISP 由驱动脚本加载）
        readonly List<(int row, Point3d at, string style)> annos = new List<(int, Point3d, string)>();

        // "anno": [x,y]（类默认标注样式） 或 {"at":[x,y],"style":"Pipeline Tag"}；管线默认 Pipeline Tag（否则会取到列表第一项 Insulation）
        void Anno(JsonElement it, int rid)
        {
            if (rid <= 0 || !it.TryGetProperty("anno", out var a)) return;
            string st = it.GetProperty("k").GetString() == "line" ? "Pipeline Tag" : "";
            if (a.ValueKind == JsonValueKind.Object) { if (a.TryGetProperty("style", out var sv)) st = sv.GetString(); a = a.GetProperty("at"); }
            annos.Add((rid, P(a), st));
        }

        void WriteAnnoScript(string path)
        {
            var sb = new System.Text.StringBuilder();
            foreach (var (row, at, st) in annos)
            {
                ObjectId oid = ObjectId.Null;
                foreach (PpObjectId pp in dlm.FindAcPpObjectIds(row)) { oid = dlm.MakeAcDbObjectId(pp); if (oid.IsValid) break; }
                if (!oid.IsValid) { L($"  标注跳过 row={row}：找不到图元"); continue; }
                // "_non"：本点不受运行中对象捕捉影响（否则位号会被吸到附近的线或文字上，P&ID-103 HV-301 实例）
                sb.AppendLine(FormattableString.Invariant($"(command \"_PIDANNOTATE\" (handent \"{oid.Handle}\") \"{st}\" \"_non\" \"{at.X:F2},{at.Y:F2}\")"));
            }
            sb.AppendLine("(princ)");
            File.WriteAllText(path, sb.ToString(), new System.Text.UTF8Encoding(false));
            L($"标注脚本: {path}（{annos.Count} 条）");
        }

        // ---------------------------------------------------------------- 自定义符号样式（块几何 + AssetStyle）
        // {"k":"style","name":"SOEC Furnace Style","class":"Furnace","desc":"..","geom":[
        //    {"pl":[[x,y],...],"c":true,"lt":"DASHED"}, {"circle":[x,y,r]}, {"t":"文字","at":[x,y],"h":2.5,"just":"MC"} ]}
        // 几何以插入点为原点，按实际尺寸（mm）绘制；插入时 scale=1。
        void AddStyleDef(JsonElement it)
        {
            string name = it.GetProperty("name").GetString();
            ObjectId existing = ObjectId.Null;
            try { existing = PnIDStyleUtils.GetStyleIdFromName(name, false); } catch { }
            if (existing.IsValid) { L($"style {name} 已存在，跳过"); return; }
            string bname = "PIDBOT_" + System.Text.RegularExpressions.Regex.Replace(name, @"[^A-Za-z0-9_]", "_");
            ObjectId btrId;
            using (var tr = db.TransactionManager.StartTransaction())
            {
                var bt = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                var tt = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
                if (bt.Has(bname)) btrId = bt[bname];
                else
                {
                    bt.UpgradeOpen();
                    var btr = new BlockTableRecord { Name = bname, Origin = Point3d.Origin };
                    btrId = bt.Add(btr);
                    tr.AddNewlyCreatedDBObject(btr, true);
                    foreach (var g in it.GetProperty("geom").EnumerateArray())
                    {
                        Entity e;
                        if (g.TryGetProperty("pl", out var pl))
                        {
                            var p = new Polyline();
                            int i = 0;
                            foreach (var v in pl.EnumerateArray()) p.AddVertexAt(i++, new Point2d(v[0].GetDouble(), v[1].GetDouble()), 0, 0, 0);
                            p.Closed = g.TryGetProperty("c", out var c) && c.GetBoolean();
                            e = p;
                        }
                        else if (g.TryGetProperty("circle", out var ci))
                            e = new Circle(new Point3d(ci[0].GetDouble(), ci[1].GetDouble(), 0), Vector3d.ZAxis, ci[2].GetDouble());
                        else if (g.TryGetProperty("t", out var t))
                            e = new MText
                            {
                                Contents = t.GetString().Replace("\n", "\\P"),
                                Location = new Point3d(g.GetProperty("at")[0].GetDouble(), g.GetProperty("at")[1].GetDouble(), 0),
                                TextHeight = Dbl(g, "h", 2.5),
                                TextStyleId = tt[TextStyleName],
                                Attachment = Just(Str(g, "just", "MC")),
                            };
                        else continue;
                        e.Layer = "0";
                        e.ColorIndex = 0;
                        string lt = Str(g, "lt", null);
                        if (lt != null) e.LinetypeId = LineType(tr, lt);
                        else e.Linetype = "ByBlock";
                        btr.AppendEntity(e);
                        tr.AddNewlyCreatedDBObject(e, true);
                    }
                }
                tr.Commit();
            }
            using var st = new Autodesk.ProcessPower.Styles.AssetStyle();
            st.BlockTableRecord = btrId;
            st.ClassName = it.GetProperty("class").GetString();
            st.Description = Str(it, "desc", name);
            st.ScaleFactor = 1.0;
            PnIDStyleUtils.AddStyle(st, name, db);
            string cls = st.ClassName;
            st.Dispose();
            var sid = PnIDStyleUtils.GetStyleIdFromName(name, false);
            L($"style {name} 已创建 class={cls} valid={sid.IsValid}");
        }

        // ---------------------------------------------------------------- Plant 对象
        void AddAsset(JsonElement it, string id)
        {
            string style = it.GetProperty("style").GetString();
            EnsureStyle(style);
            double rot = Deg(it, "rot");
            int rid;
            using (var adder = new AssetAdder(db, Bool(it, "auto", AutoDefault)))
                rid = it.TryGetProperty("scale", out var sc)
                    ? adder.Add(P(it.GetProperty("at")), rot, style, new Scale3d(sc.GetDouble()))
                    : adder.Add(P(it.GetProperty("at")), rot, style);
            if (rid <= 0) throw new InvalidOperationException("AssetAdder 未返回行号");
            Remember(id, rid);
            Anno(it, rid);
            SetProps(rid, it, "props");
            L($"asset {id} [{style}] row={rid}");
        }

        void AddCv(JsonElement it, string id)
        {
            string body = it.GetProperty("body").GetString();
            string act = it.GetProperty("act").GetString();
            EnsureStyle(body); EnsureStyle(act);
            int rid;
            using (var adder = new AssetAdder(db, Bool(it, "auto", AutoDefault)))
                rid = it.TryGetProperty("scale", out var sc)
                    ? adder.AddControlValve(P(it.GetProperty("at")), body, act, Deg(it, "rot"), new Scale3d(sc.GetDouble()))
                    : adder.AddControlValve(P(it.GetProperty("at")), body, act, Deg(it, "rot"));
            if (rid <= 0) throw new InvalidOperationException("AddControlValve 未返回行号");
            Remember(id, rid);
            Anno(it, rid);
            SetProps(rid, it, "props");
            L($"cv {id} [{body}+{act}] row={rid}");
        }

        void AddNozzle(JsonElement it, string id)
        {
            string style = it.GetProperty("style").GetString();
            EnsureStyle(style);
            int owner = rows[it.GetProperty("on").GetString()];
            int rid;
            using (var adder = new AssetAdder(db, EnvOn("PB_NOZZLE_AUTO", true)))
                rid = adder.AddNozzleToAsset(owner, style, P(it.GetProperty("at")), Deg(it, "rot"));
            Remember(id, rid);
            Anno(it, rid);
            SetProps(rid, it, "props");
            L($"nozzle {id} on {it.GetProperty("on").GetString()} row={rid}");
        }

        void AddLine(JsonElement it, string id)
        {
            string style = it.GetProperty("style").GetString();
            EnsureStyle(style);
            var pts = new Point3dCollection();
            foreach (var p in it.GetProperty("pts").EnumerateArray()) pts.Add(P(p));
            // 同一管线号的多段线归入同一线组（本图内）；不自动连接/建管嘴，连接全部由 spec 显式建立，避免重复处理同一拓扑
            string ln = it.TryGetProperty("group", out var g0) && g0.TryGetProperty("LineNumber", out var lnv) ? lnv.GetString() : null;
            int rid;
            using (var adder = new LineSegmentAdder(db, EnvOn("PB_LINE_AUTO", true)) { MergeGroups = false, MergeLines = false, CreateConnections = Bool(it, "auto", false), CreateNozzle = false })
            {
                if (ln != null && groups.TryGetValue(ln, out int gexist)) rid = adder.Add(pts, style, gexist);
                else rid = adder.Add(pts, style);
            }
            if (rid <= 0) throw new InvalidOperationException("LineSegmentAdder 未返回行号");
            Remember(id, rid);
            Anno(it, rid);
            SetProps(rid, it, "props");
            if (it.TryGetProperty("group", out _))
            {
                int gid;
                using (var lgm = new LineGroupManager(dlm)) gid = lgm.GroupId(rid);
                if (ln != null) groups[ln] = gid;
                SetProps(gid, it, "group");
                L($"line {id} [{style}] row={rid} group={gid}");
            }
            else L($"line {id} [{style}] row={rid}");
        }

        readonly Dictionary<string, int> groups = new Dictionary<string, int>();

        // ---------------------------------------------------------------- 跨图对象登记（spec 目录下 *.ids.json 合并读取；本图写回 <spec>.ids.json）
        void LoadRegistry(string specPath)
        {
            string dir = Path.GetDirectoryName(specPath);
            string self = Path.ChangeExtension(specPath, ".ids.json");
            foreach (var f in Directory.GetFiles(dir, "*.ids.json"))
            {
                if (string.Equals(f, self, StringComparison.OrdinalIgnoreCase)) continue;
                try
                {
                    using var js = JsonDocument.Parse(File.ReadAllText(f));
                    foreach (var p in js.RootElement.EnumerateObject()) rows[p.Name] = p.Value.GetInt32();
                }
                catch (System.Exception ex) { L($"读取登记失败 {f}: {ex.Message}"); }
            }
        }

        void SaveRegistry(string specPath, HashSet<string> own)
        {
            var d = rows.Where(kv => own.Contains(kv.Key)).ToDictionary(kv => kv.Key, kv => kv.Value);
            File.WriteAllText(Path.ChangeExtension(specPath, ".ids.json"), JsonSerializer.Serialize(d, new JsonSerializerOptions { WriteIndented = true, Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping }), new System.Text.UTF8Encoding(false));
        }

        readonly HashSet<string> ownIds = new HashSet<string>();

        // ---------------------------------------------------------------- 连接关系
        // {"k":"connect","line":"L1","asset":"V1","ctx":"inline|start|end"}   线-对象（内联/起点/终点）
        // {"k":"tee","line":"L2","to":"L1","start":true}                       L2 的起点(或终点)接到 L1 上（三通）
        // {"k":"opc","a":"OPC1","b":12345}                                       跨图连接器配对（id 或行号）
        int Row(JsonElement v)
        {
            if (v.ValueKind == JsonValueKind.Number) return v.GetInt32();
            string s = v.GetString();
            if (rows.TryGetValue(s, out int r)) return r;
            if (int.TryParse(s, out r)) return r;
            throw new ArgumentException("未知对象 " + s);
        }

        ObjectId Oid(int rid)
        {
            foreach (PpObjectId pp in dlm.FindAcPpObjectIds(rid))
            {
                var o = dlm.MakeAcDbObjectId(pp);
                if (!o.IsNull && o.IsValid && !o.IsErased && o.Database == db) return o;
            }
            throw new ArgumentException("当前图纸中找不到图元 row=" + rid);
        }

        void Connect(JsonElement it)
        {
            int line = Row(it.GetProperty("line")), asset = Row(it.GetProperty("asset"));
            var ctx = Str(it, "ctx", "inline").ToLowerInvariant() switch
            {
                "start" => AssetContext.ContextStart,
                "end" => AssetContext.ContextEnd,
                _ => AssetContext.ContextInline,
            };
            // 注：曾在此先用 dlm.GetRelatedRowIds(line) 查重，随后的 ConnectLineWithAsset 即触发
            // eNotOpenForWrite 闪退（logs/incident_20261007-1206），已撤销；绘图中不要在连接前查询关系
            // 在独立事务中调用：Plant 内部打开的对象随事务提交关闭，避免遗留读者导致后续 eWasOpenForRead / eHadMultipleReaders
            if (EnvOn("PB_CONN_ROWID", false))
                LineUtil.ConnectLineWithAsset(line, asset, ctx);   // 官方示例写法：行号重载，不套事务
            else
                using (var tr = db.TransactionManager.StartTransaction())
                {
                    LineUtil.ConnectLineWithAsset(Oid(line), Oid(asset), ctx);
                    tr.Commit();
                }
            L($"connect line={line} asset={asset} {ctx}");
        }

        void Tee(JsonElement it)
        {
            int self = Row(it.GetProperty("line")), to = Row(it.GetProperty("to"));
            bool start = !it.TryGetProperty("start", out var s) || s.GetBoolean();
            using (var tr = db.TransactionManager.StartTransaction())
            {
                LineUtil.ConnectLineWithLine(Oid(self), Oid(to), start);
                tr.Commit();
            }
            L($"tee line={self} {(start ? "起点" : "终点")} → line={to}");
        }

        void Opc(JsonElement it)
        {
            int a = Row(it.GetProperty("a")), b = Row(it.GetProperty("b"));
            // 行号重载未实现（eNotImplementedYet）；改用 PpObjectId 重载，对方图纸未打开也可配对
            PpObjectId pa = default, pb = default;
            bool fa = false, fb = false;
            foreach (PpObjectId x in dlm.FindAcPpObjectIds(a)) { pa = x; fa = true; break; }
            foreach (PpObjectId x in dlm.FindAcPpObjectIds(b)) { pb = x; fb = true; break; }
            if (!fa || !fb) throw new ArgumentException($"找不到跨图连接器 PpObjectId（{a}/{b}）");
            try { using (var om = new OffpageConnectionManager(dlm)) om.Connect(pa, pb); }
            catch (System.Exception ex) when ((ex.Message ?? "").Contains("eNotImplementedYet"))
            {
                // 2026 托管层未实现：改用 DLM 正式关系 API 建立与 UI“连接到”相同的 ConnectorsRelationship
                dlm.Relate("ConnectorsRelationship", "Connector1", a, "Connector2", b);
                L("  OffpageConnectionManager 未实现，已用 DataLinksManager.Relate(ConnectorsRelationship) 配对");
            }
            L($"opc {a} ↔ {b}");
        }

        void Remember(string id, int rid)
        {
            if (!string.IsNullOrEmpty(id)) { rows[id] = rid; ownIds.Add(id); }
        }

        // ---------------------------------------------------------------- 图例符号（样式块的普通块参照，不进 Plant 数据）
        // {"k":"sym","style":"Ball Valve Style","at":[x,y],"scale":8,"rot":0}   scale 省略取样式比例
        void AddSym(JsonElement it)
        {
            string style = it.GetProperty("style").GetString();
            EnsureStyle(style);
            var sid = PnIDStyleUtils.GetStyleIdFromName(style, false);
            using var tr = db.TransactionManager.StartTransaction();
            var st = (Autodesk.ProcessPower.Styles.Style)tr.GetObject(sid, OpenMode.ForRead);
            if (!st.BlockTableRecord.IsValid) throw new ArgumentException("样式无块: " + style);
            double sc = it.TryGetProperty("scale", out var s) ? s.GetDouble() : (st is Autodesk.ProcessPower.Styles.AssetStyle a ? a.ScaleFactor : 1.0);
            var br = new BlockReference(P(it.GetProperty("at")), st.BlockTableRecord) { ScaleFactors = new Scale3d(sc), Rotation = Deg(it, "rot") };
            Style(tr, br, it);
            Append(tr, br);
            tr.Commit();
        }

        // ---------------------------------------------------------------- 表格（细实线网格 + 单元格文字，外框粗线）
        // {"k":"table","at":[x,yTop],"cols":[w1,w2..],"rowh":7,"h":3,"rows":[["..",".."],...],"header":1}
        void AddTable(JsonElement it)
        {
            var at = P(it.GetProperty("at"));
            var cols = it.GetProperty("cols").EnumerateArray().Select(v => v.GetDouble()).ToArray();
            double rh = Dbl(it, "rowh", 7), th = Dbl(it, "h", 3);
            var rowsEl = it.GetProperty("rows").EnumerateArray().ToList();
            int header = Int(it, "header", 1);
            var heights = rowsEl.Select(r => Math.Max(1, r.EnumerateArray().Max(c => (c.GetString() ?? "").Split('\n').Length)) * rh).ToList();
            double W = cols.Sum(), H = heights.Sum();
            using var tr = db.TransactionManager.StartTransaction();
            var tt = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
            EnsureLayerInTr(tr, "表格");
            void Ln(double x0, double y0, double x1, double y1, LineWeight lw)
                => Append(tr, new Line(new Point3d(x0, y0, 0), new Point3d(x1, y1, 0)) { Layer = "表格", LineWeight = lw });
            double y = at.Y;
            for (int r = 0; r <= rowsEl.Count; r++)
            {
                Ln(at.X, y, at.X + W, y, (r == 0 || r == rowsEl.Count) ? LineWeight.LineWeight050 : (r == header ? LineWeight.LineWeight035 : LineWeight.LineWeight018));
                if (r < rowsEl.Count) y -= heights[r];
            }
            double x = at.X;
            for (int c = 0; c <= cols.Length; c++)
            {
                Ln(x, at.Y, x, at.Y - H, (c == 0 || c == cols.Length) ? LineWeight.LineWeight050 : LineWeight.LineWeight018);
                if (c < cols.Length) x += cols[c];
            }
            y = at.Y;
            for (int r = 0; r < rowsEl.Count; r++)
            {
                x = at.X;
                int c = 0;
                foreach (var cell in rowsEl[r].EnumerateArray())
                {
                    if (c >= cols.Length) break;
                    string s = cell.GetString() ?? "";
                    if (s.Length > 0)
                    {
                        bool center = r < header || s.Length <= 3;
                        Append(tr, new MText
                        {
                            Contents = s.Replace("\n", "\\P"), TextHeight = th, TextStyleId = tt[TextStyleName], Layer = "表格",
                            Attachment = center ? AttachmentPoint.MiddleCenter : AttachmentPoint.MiddleLeft,
                            Location = new Point3d(center ? x + cols[c] / 2 : x + 1.2, y - heights[r] / 2, 0),
                        });
                    }
                    x += cols[c]; c++;
                }
                y -= heights[r];
            }
            tr.Commit();
        }

        void SetProps(int rid, JsonElement it, string key)
        {
            if (!it.TryGetProperty(key, out var props) || rid <= 0) return;
            var names = new StringCollection();
            var vals = new StringCollection();
            foreach (var p in props.EnumerateObject()) { names.Add(p.Name); vals.Add(p.Value.ToString()); }
            if (names.Count == 0) return;
            try { dlm.SetProperties(rid, names, vals); }
            catch (System.Exception ex) { L($"  属性写入失败 row={rid} ({string.Join(",", names.Cast<string>())}): {ex.Message}"); }
        }

        void EnsureStyle(string name)
        {
            ObjectId sid = ObjectId.Null;
            try { sid = PnIDStyleUtils.GetStyleIdFromName(name, false); } catch { }
            if (sid.IsValid) return;
            if (symDb == null)
            {
                symDb = new Database(false, true);
                symDb.ReadDwgFile(PlantApplication.ProjectPart("PnId").SymbolAndStyleCacheFile, FileOpenMode.OpenForReadAndAllShare, true, null);
            }
            var copied = ProjectSymbolStyleUtils.CopyStyle(name, symDb, db);
            if (!copied.IsValid) throw new ArgumentException("样式不存在: " + name);
            L($"  已从项目符号库复制样式: {name}");
        }

        // ---------------------------------------------------------------- 普通 CAD 注释
        // 与 GB 模板一致：gbenor.shx + gbcbig.shx，宽度 1（长仿宋）
        const string TextStyleName = Template.TextStyle;

        void EnsureTextStyle()
        {
            using var tr = db.TransactionManager.StartTransaction();
            Template.EnsureTextStyle(tr, db);
            tr.Commit();
        }

        void EnsureLayer(string name, int color, string ltype, int lw = 0)
        {
            using var tr = db.TransactionManager.StartTransaction();
            var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            LayerTableRecord rec;
            if (!lt.Has(name))
            {
                lt.UpgradeOpen();
                rec = new LayerTableRecord { Name = name };
                lt.Add(rec);
                tr.AddNewlyCreatedDBObject(rec, true);
            }
            else rec = (LayerTableRecord)tr.GetObject(lt[name], OpenMode.ForWrite);
            rec.Color = Color.FromColorIndex(ColorMethod.ByAci, (short)color);
            if (!string.IsNullOrEmpty(ltype)) rec.LinetypeObjectId = LineType(tr, ltype);
            if (lw > 0) rec.LineWeight = (LineWeight)lw;
            tr.Commit();
        }

        ObjectId LineType(Transaction tr, string name)
        {
            var ltt = (LinetypeTable)tr.GetObject(db.LinetypeTableId, OpenMode.ForRead);
            if (!ltt.Has(name)) db.LoadLineTypeFile(name, "acadiso.lin");
            return ltt[name];
        }

        void Style(Transaction tr, Entity e, JsonElement it)
        {
            string layer = Str(it, "layer", null);
            if (layer != null) { EnsureLayerInTr(tr, layer); e.Layer = layer; }
            if (it.TryGetProperty("color", out var c)) e.ColorIndex = c.GetInt32();
            string lt = Str(it, "ltype", null);
            if (lt != null) e.LinetypeId = LineType(tr, lt);
        }

        void EnsureLayerInTr(Transaction tr, string name)
        {
            var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            if (lt.Has(name)) return;
            lt.UpgradeOpen();
            var rec = new LayerTableRecord { Name = name };
            lt.Add(rec);
            tr.AddNewlyCreatedDBObject(rec, true);
        }

        void Append(Transaction tr, Entity e)
        {
            var ms = (BlockTableRecord)tr.GetObject(SymbolUtilityServices.GetBlockModelSpaceId(db), OpenMode.ForWrite);
            ms.AppendEntity(e);
            tr.AddNewlyCreatedDBObject(e, true);
        }

        void AddText(JsonElement it)
        {
            using var tr = db.TransactionManager.StartTransaction();
            var tt = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
            var mt = new MText
            {
                Contents = it.GetProperty("text").GetString().Replace("\n", "\\P"),
                Location = P(it.GetProperty("at")),
                TextHeight = Dbl(it, "h", 2.5),
                TextStyleId = tt[TextStyleName],
                Rotation = Deg(it, "rot"),
                Attachment = Just(Str(it, "just", "ML")),
            };
            double w = Dbl(it, "w", 0);
            if (w > 0) mt.Width = w;
            Style(tr, mt, it);
            Append(tr, mt);
            tr.Commit();
        }

        void AddPoly(JsonElement it)
        {
            var pts = it.GetProperty("pts").EnumerateArray().Select(P).ToList();
            MakePoly(it, pts, it.TryGetProperty("closed", out var c) && c.GetBoolean());
        }

        void AddRect(JsonElement it)
        {
            var a = P(it.GetProperty("at")); var b = P(it.GetProperty("to"));
            MakePoly(it, new List<Point3d> { a, new Point3d(b.X, a.Y, 0), b, new Point3d(a.X, b.Y, 0) }, true);
        }

        void MakePoly(JsonElement it, List<Point3d> pts, bool closed)
        {
            using var tr = db.TransactionManager.StartTransaction();
            var pl = new Polyline();
            for (int i = 0; i < pts.Count; i++) pl.AddVertexAt(i, new Point2d(pts[i].X, pts[i].Y), 0, 0, 0);
            pl.Closed = closed;
            double lw = Dbl(it, "lw", 0);
            if (lw > 0) pl.ConstantWidth = lw;
            Style(tr, pl, it);
            Append(tr, pl);
            tr.Commit();
        }

        // ---------------------------------------------------------------- 工具
        Point3d P(JsonElement a) => new Point3d(a[0].GetDouble(), a[1].GetDouble(), 0) + off;
        static double Deg(JsonElement it, string k) => Dbl(it, k, 0) * Math.PI / 180.0;
        static double Dbl(JsonElement it, string k, double d) => it.TryGetProperty(k, out var v) ? v.GetDouble() : d;
        static int Int(JsonElement it, string k, int d) => it.TryGetProperty(k, out var v) ? v.GetInt32() : d;
        static bool EnvOn(string n, bool def) { var v = Environment.GetEnvironmentVariable(n); return v == null ? def : v != "0"; }
        const bool AutoDefault = false;   // 资产/控制阀默认关闭自动化：连接全部由 spec 显式建立
        static bool Bool(JsonElement it, string k, bool d) => it.TryGetProperty(k, out var v) ? v.GetBoolean() : d;
        static string Str(JsonElement it, string k, string d) => it.TryGetProperty(k, out var v) ? v.GetString() : d;

        static AttachmentPoint Just(string j) => j.ToUpperInvariant() switch
        {
            "TL" => AttachmentPoint.TopLeft, "TC" => AttachmentPoint.TopCenter, "TR" => AttachmentPoint.TopRight,
            "ML" => AttachmentPoint.MiddleLeft, "MC" => AttachmentPoint.MiddleCenter, "MR" => AttachmentPoint.MiddleRight,
            "BL" => AttachmentPoint.BottomLeft, "BC" => AttachmentPoint.BottomCenter, "BR" => AttachmentPoint.BottomRight,
            _ => AttachmentPoint.MiddleLeft
        };
    }
}
